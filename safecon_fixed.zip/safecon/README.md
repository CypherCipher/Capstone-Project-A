# SafeCon prototype

A working prototype of the SafeCon capstone proposal (Online Grooming Detection): a chat for children inside an institution,
with parent and moderator dashboards. FastAPI + a plain HTML/JS front end (no build step).

## 1. Run it

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm

python seed.py                       # demo accounts + a demo conversation (add --fast to skip loading AI models)
python -m uvicorn app.main:app --port 8000
```

Open http://localhost:8000. All demo accounts use the password `SafeCon-Demo-2026`:

| Username      | Role      | Notes                                   |
|---------------|-----------|-----------------------------------------|
| `mod_demo`    | moderator | sees all alerts at "Demo School"        |
| `parent_demo` | parent    | parent of Sara and Omar                 |
| `parent_two`  | parent    | parent of Rami                          |
| `sara`, `omar`, `rami` | child | chat with each other                 |

The first start downloads the three Hugging Face models (about 700 MB total) in the background. The **System** tab on the
moderator dashboard shows whether each one loaded ("real model") or is using a fallback.

## 2. Demo script (5 minutes)

1. Log in as `mod_demo`: the seeded conversation already produced a High alert (secrecy + personal info), a SHAP word list,
   and a pending warning for Sara (she shared a phone number, which was masked before storing).
2. Open the alert, read the flagged conversation, press **Confirm risk**. Check the audit log tab.
3. Log in as `parent_demo` (another browser or a private window): see the alert, Sara's stars, interests, warning history, notifications.
4. Log in as `sara` and `rami` in two windows and chat. Try: "how old are you?" (no alert), then "don't tell your parents, our secret",
   then "what's your number" (alert appears). Try "thank you so much for helping me" (star; repeating it won't give another).
5. As the moderator, confirm 3 warnings for one child: their chat pauses and the parent gets a notification. Use **Restore chat** to lift it.
6. Turn on MFA from the Security tab (any authenticator app), log out, and log in again.

## 3. What is in it (proposal -> code)

| Proposal item | Where |
|---|---|
| FastAPI REST API, 3 layers (front end -> logic -> DB) | `app/main.py`, `app/routers/`, `app/services.py`, `app/db.py`, `static/` |
| Slang, emoji, spelling normalization (regex, spaCy, slang dict, emoji lib) | `app/nlp/normalize.py` |
| Conversation windows, DistilBERT grooming classifier | `app/services.py`, `app/nlp/models.py` (`erikaecl/hansen-grooming-distilbert`) |
| Sensitive-data detection (regex + spaCy NER) and masking | `app/nlp/sensitive.py` |
| ViT image check (Falconsai/nsfw_image_detection) | `app/nlp/models.py`, `app/services.py` |
| Risk rules High/Medium/Low | `app/nlp/risk.py` |
| SHAP explanations | `app/nlp/explain.py` |
| Warning system (moderator-confirmed, temporary restriction, parent notified) | `app/services.py`, `app/routers/mod.py` |
| Interests analyzer (all-MiniLM-L6-v2 + cosine) | `app/nlp/interests.py` |
| Star rewards with duplicate/cooldown checks | `app/nlp/stars.py` |
| Argon2, short-lived JWT, MFA (TOTP), lockout, rate limits, API key | `app/security.py`, `app/routers/auth.py`, `app/routers/analyze.py` |
| AES-256-GCM encrypted chat + images, 30-day / 90-day deletion | `app/security.py`, `app/services.py` (`purge_expired`, runs hourly) |
| Role-based access on every request, audit logs | `app/deps.py`, `app/routers/*.py` |
| XSS defences (textContent only, CSP, HttpOnly SameSite cookie), CSRF header | `static/app.js`, `app/main.py` |
| Security-event log for Wazuh | `data/security.log` (JSON lines, no message text) |

## 4. Decisions you should know about

- **No training.** The text model is the public `erikaecl/hansen-grooming-distilbert` (the baseline in your proposal) instead of your own PAN12 fine-tune.
  The code reads the model's label names to find the "grooming" label. If the moderator **System** tab shows the wrong label,
  set `SAFECON_TEXT_GROOMING_LABEL` (e.g. `LABEL_1`). To use your own model later, set `SAFECON_TEXT_MODEL` to its folder or Hub id.
- **Fallbacks.** If a model can't load, a rule-based stand-in keeps the app working and is labelled "fallback-rules" on every alert.
  For images the fallback is a demo stub: a file named `demo-explicit.jpg` is treated as explicit so you can test that path without the model.
- **"Personal information"** in the risk rules means shared *or* requested. A single "how old are you?" is deliberately not a request.
  Names and places only count when the child is talking about themselves ("my name is...", "I live in...").
- **Masking:** phone numbers, emails, links, usernames and addresses are replaced by `[phone hidden]` etc. *before* the message is stored.
- **Alerts hold no message text.** Moderators and parents read flagged messages from the encrypted chat store (every view is audit-logged), and flagged images are blurred until clicked.
- **Moderators** see all children of their school/centre (matched by the institution name typed at sign-up). Parents see only their own children's alerts.
- Chat is children chatting with other children at the same institution (polling every 2.5 s, no websockets).

## 5. Prototype shortcuts (what to say in your report)

SQLite instead of PostgreSQL, in-memory rate limiter, MFA optional (not forced), keys auto-generated in `data/.secrets/`
(set `SAFECON_DATA_KEY`, `SAFECON_JWT_SECRET`, `SAFECON_API_KEY` in production), no password reset or email, and no backup job.

**TLS 1.3 only** is done at a reverse proxy, e.g. nginx: `ssl_protocols TLSv1.3;` then run with `SAFECON_COOKIE_SECURE=1`.

## 6. Tests and security checks

```bash
python -m pytest -q tests                 # 13 tests: auth, lockout, MFA, roles, masking, risk rules, alerts, stars, images, retention
bandit -r app                             # static analysis
pip-audit -r requirements.txt             # vulnerable packages
# OWASP ZAP: point a baseline scan at http://localhost:8000
```
Tests run with `SAFECON_MODELS=off`, so they use the fallbacks and need no downloads.

`/api/docs` has the interactive API docs. The service key for `/api/analyze` is in `data/.secrets/api_key`.
