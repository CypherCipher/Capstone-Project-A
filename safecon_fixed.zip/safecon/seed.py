"""Create demo accounts and (optionally) a demo conversation so every dashboard has something to show.
Usage:  python seed.py            # accounts + demo chat, loads the real models if available
        python seed.py --fast    # skip loading the AI models (uses the rule-based fallback)
        python seed.py --no-chat # accounts only"""
import sys

from app import config
from app.db import Institution, SessionLocal, User, Conversation, init_db
from app.nlp import models
from app.security import hash_password
from app.services import handle_message

PW = "SafeCon-Demo-2026"
INST = "Demo School"


def get_or_create(db, username, role, name, inst_id, parent_id=None):
    u = db.query(User).filter(User.username == username).first()
    if u:
        return u, False
    u = User(username=username, password_hash=hash_password(PW), role=role, full_name=name,
             institution_id=inst_id, parent_id=parent_id)
    db.add(u)
    db.commit()
    return u, True


def main():
    fast = "--fast" in sys.argv
    init_db()
    with SessionLocal() as db:
        inst = db.query(Institution).filter(Institution.name == INST).first() or Institution(name=INST)
        db.add(inst); db.commit()
        mod, _ = get_or_create(db, "mod_demo", "moderator", "Dana (Moderator)", inst.id)
        p1, _ = get_or_create(db, "parent_demo", "parent", "Hana (Parent)", inst.id)
        p2, _ = get_or_create(db, "parent_two", "parent", "Karim (Parent)", inst.id)
        sara, _ = get_or_create(db, "sara", "child", "Sara", inst.id, p1.id)
        omar, _ = get_or_create(db, "omar", "child", "Omar", inst.id, p1.id)
        rami, new_rami = get_or_create(db, "rami", "child", "Rami", inst.id, p2.id)

        if "--no-chat" not in sys.argv and new_rami:
            if not fast:
                print("Loading AI models (first run downloads them; falls back automatically if it can't)...")
                models.load_all()
                for k, v in models.STATUS.items():
                    print(f"  {k}: {v['state']} {v['detail']}")
            a, b = sorted((sara.id, rami.id))
            conv = Conversation(user_a=a, user_b=b); db.add(conv); db.commit()
            script = [
                (sara, "hi! did you see the football match yesterday?"),
                (rami, "hey sara, yeah it was great. how old are you btw?"),
                (sara, "I'm 12, you?"),
                (rami, "you are so mature for your age, i really understand you"),
                (rami, "are your parents home right now?"),
                (sara, "no they are out"),
                (rami, "good. dont tell ur parents we talk, this is our secret ok?"),
                (rami, "whats ur number? i can text you and we can meet up"),
                (sara, "my number is 050 123 4567"),
                (sara, "thank you for being so nice to me, i appreciate it"),
            ]
            for sender, text in script:
                handle_message(db, sender, conv, text, None)
            print("Demo conversation created.")

    print("\nDemo logins (password for all: %s)" % PW)
    for u, role in (("mod_demo", "moderator"), ("parent_demo", "parent (Sara and Omar's parent)"),
                    ("parent_two", "parent (Rami's parent)"), ("sara", "child"), ("omar", "child"), ("rami", "child")):
        print(f"  {u:<12} {role}")
    print("\nService API key for /api/analyze:", config.API_KEY)


if __name__ == "__main__":
    main()
