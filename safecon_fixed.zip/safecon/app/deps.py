from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .config import COOKIE_NAME
from .db import AuditLog, SessionLocal, User, utcnow
from .security import read_token


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get(COOKIE_NAME)
    data = read_token(token) if token else None
    if not data:
        raise HTTPException(401, "Please log in.")
    user = db.get(User, int(data["sub"]))
    if not user or not user.active:
        raise HTTPException(401, "Please log in.")
    return user


def require(*roles: str):
    def dep(user: User = Depends(current_user)) -> User:
        if user.role not in roles:           # role check on EVERY request (broken access control)
            raise HTTPException(403, "You don't have access to this.")
        return user
    return dep


def audit(db: Session, user: User | None, action: str, target: str = "", request: Request | None = None):
    ip = request.client.host if request and request.client else None
    db.add(AuditLog(user_id=user.id if user else None, action=action, target=target[:80], ip=ip, created_at=utcnow()))
    db.commit()


def is_restricted(user: User) -> bool:
    return bool(user.restricted_until and user.restricted_until > utcnow())
