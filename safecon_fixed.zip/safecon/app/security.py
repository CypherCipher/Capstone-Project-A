"""Passwords (Argon2), JWT sessions, AES-256-GCM encryption, rate limiting, security log."""
import json
import os
import re
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import HTTPException, Request

from .config import DATA_DIR, DATA_KEY, JWT_MINUTES, JWT_SECRET

_ph = PasswordHasher()
_DUMMY_HASH = _ph.hash("dummy-password-for-timing")
_COMMON = {"password", "password1", "123456789", "1234567890", "qwertyuiop", "iloveyou12", "letmein123", "admin12345"}


def hash_password(pw: str) -> str:
    return _ph.hash(pw)


def verify_password(pw_hash: str | None, pw: str) -> bool:
    """Always does one Argon2 verification so unknown users cost the same time as known ones."""
    try:
        _ph.verify(pw_hash or _DUMMY_HASH, pw)
        return pw_hash is not None
    except (VerifyMismatchError, InvalidHashError):
        return False


def check_password_policy(pw: str, username: str = "") -> None:
    """Length-first policy in the spirit of NIST 800-63B (no forced symbol rules)."""
    if len(pw) < 10:
        raise HTTPException(400, "Password must be at least 10 characters.")
    if len(pw) > 128:
        raise HTTPException(400, "Password is too long (max 128).")
    if pw.lower() in _COMMON or (username and username.lower() in pw.lower()):
        raise HTTPException(400, "That password is too easy to guess.")


def make_token(user) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode(
        {"sub": str(user.id), "role": user.role, "iat": now, "exp": now + timedelta(minutes=JWT_MINUTES)},
        JWT_SECRET, algorithm="HS256",
    )


def read_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None


def encrypt(data: bytes) -> bytes:
    nonce = os.urandom(12)
    return nonce + AESGCM(DATA_KEY).encrypt(nonce, data, None)


def decrypt(blob: bytes) -> bytes:
    return AESGCM(DATA_KEY).decrypt(blob[:12], blob[12:], None)


class RateLimiter:
    """Tiny in-memory sliding-window limiter (fine for a prototype; use Redis in production)."""

    def __init__(self, limit: int, window_s: int, name: str):
        self.limit, self.window, self.name = limit, window_s, name
        self.hits: dict[str, deque] = defaultdict(deque)
        self.lock = threading.Lock()

    def __call__(self, request: Request):
        key = request.client.host if request.client else "unknown"
        now = time.monotonic()
        with self.lock:
            q = self.hits[key]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.limit:
                sec_log("rate_limited", route=self.name, ip=key)
                raise HTTPException(429, "Too many requests. Please slow down.")
            q.append(now)


_log_lock = threading.Lock()


def sec_log(event: str, **fields) -> None:
    """JSON-lines security log (never contains message text). Point Wazuh at data/security.log."""
    rec = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"), "event": event, **fields}
    with _log_lock, open(DATA_DIR / "security.log", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
