import base64

import pyotp
import segno
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .. import config
from ..db import Institution, User, utcnow
from ..deps import audit, current_user, get_db
from ..security import (USERNAME_RE, RateLimiter, check_password_policy, hash_password, make_token, sec_log,
                        verify_password)
from datetime import timedelta

router = APIRouter(prefix="/api/auth", tags=["auth"])
limit_login = RateLimiter(10, 60, "login")
limit_register = RateLimiter(10, 60, "register")
HOME = {"child": "/chat.html", "parent": "/parent.html", "moderator": "/moderator.html"}


class RegisterIn(BaseModel):
    username: str
    password: str
    full_name: str = Field(min_length=2, max_length=60)
    role: str
    institution: str = Field(min_length=2, max_length=80)


class LoginIn(BaseModel):
    username: str
    password: str
    totp: str | None = None


class CodeIn(BaseModel):
    code: str


def user_json(u: User, db: Session) -> dict:
    inst = db.get(Institution, u.institution_id) if u.institution_id else None
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role,
            "institution": inst.name if inst else None, "stars": u.stars, "mfa_enabled": bool(u.mfa_enabled),
            "restricted_until": u.restricted_until.isoformat() if u.restricted_until and u.restricted_until > utcnow() else None,
            "home": HOME[u.role]}


@router.post("/register", dependencies=[Depends(limit_register)])
def register(body: RegisterIn, request: Request, db: Session = Depends(get_db)):
    """Parents and moderators sign up here. Child accounts are created by a parent."""
    if body.role not in ("parent", "moderator"):
        raise HTTPException(400, "Choose parent or moderator. Child accounts are created by a parent.")
    if not USERNAME_RE.match(body.username):
        raise HTTPException(400, "Username: 3-32 letters, numbers, dot, dash or underscore.")
    check_password_policy(body.password, body.username)
    if db.query(User).filter(User.username == body.username.lower()).first():
        raise HTTPException(409, "That username is taken.")
    name = " ".join(body.institution.split())
    inst = db.query(Institution).filter(Institution.name == name).first()
    if not inst:
        inst = Institution(name=name)
        db.add(inst)
        db.flush()
    user = User(username=body.username.lower(), password_hash=hash_password(body.password),
                role=body.role, full_name=body.full_name.strip(), institution_id=inst.id)
    db.add(user)
    db.commit()
    audit(db, user, "register", body.role, request)
    sec_log("register", user=user.id, role=user.role, ip=request.client.host)
    return {"ok": True}


@router.post("/login", dependencies=[Depends(limit_login)])
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ip = request.client.host if request.client else "?"
    user = db.query(User).filter(User.username == body.username.lower()).first()
    if user and user.locked_until and user.locked_until > utcnow():
        sec_log("login_blocked_locked", user=user.id, ip=ip)
        raise HTTPException(423, "Account locked for a few minutes after too many attempts.")
    ok = verify_password(user.password_hash if user else None, body.password)

    def fail(reason: str):
        if user:
            user.failed_attempts = (user.failed_attempts or 0) + 1
            if user.failed_attempts >= config.MAX_FAILED_LOGINS:
                user.locked_until = utcnow() + timedelta(minutes=config.LOCKOUT_MINUTES)
                user.failed_attempts = 0
                sec_log("account_locked", user=user.id, ip=ip)
            db.commit()
        sec_log("login_failed", user=user.id if user else None, reason=reason, ip=ip)
        raise HTTPException(401, "Wrong username, password or code.")

    if not ok or not user.active:
        fail("bad_password")
    if user.mfa_enabled:
        if not body.totp:
            return {"mfa_required": True}
        if not pyotp.TOTP(user.mfa_secret).verify(body.totp.strip(), valid_window=1):
            fail("bad_totp")
    user.failed_attempts, user.locked_until = 0, None
    db.commit()
    response.set_cookie(config.COOKIE_NAME, make_token(user), httponly=True, samesite="strict",
                        secure=config.COOKIE_SECURE, max_age=config.JWT_MINUTES * 60, path="/")
    audit(db, user, "login", "", request)
    sec_log("login_ok", user=user.id, role=user.role, ip=ip)
    return {"ok": True, "home": HOME[user.role]}


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(config.COOKIE_NAME, path="/")
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return user_json(user, db)


@router.post("/mfa/setup")
def mfa_setup(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.mfa_enabled:
        raise HTTPException(400, "MFA is already on.")
    user.mfa_secret = pyotp.random_base32()
    db.commit()
    uri = pyotp.TOTP(user.mfa_secret).provisioning_uri(name=user.username, issuer_name="SafeCon")
    svg = segno.make(uri).svg_data_uri(scale=5, dark="#10252B")
    return {"secret": user.mfa_secret, "uri": uri, "qr": svg}


@router.post("/mfa/enable")
def mfa_enable(body: CodeIn, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not user.mfa_secret or not pyotp.TOTP(user.mfa_secret).verify(body.code.strip(), valid_window=1):
        raise HTTPException(400, "That code didn't match. Try the newest code in your app.")
    user.mfa_enabled = True
    db.commit()
    audit(db, user, "mfa_enabled", "", request)
    return {"ok": True}


@router.post("/mfa/disable")
def mfa_disable(body: CodeIn, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not user.mfa_enabled or not pyotp.TOTP(user.mfa_secret).verify(body.code.strip(), valid_window=1):
        raise HTTPException(400, "That code didn't match.")
    user.mfa_enabled, user.mfa_secret = False, None
    db.commit()
    audit(db, user, "mfa_disabled", "", request)
    return {"ok": True}
