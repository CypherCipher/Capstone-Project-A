from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, Response, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import config, services
from ..db import Conversation, Message, User, utcnow
from ..deps import audit, current_user, get_db, is_restricted, require
from ..security import RateLimiter, decrypt

router = APIRouter(prefix="/api/chat", tags=["chat"])
limit_send = RateLimiter(40, 60, "send_message")


class StartIn(BaseModel):
    with_user_id: int


def _conv_or_404(db: Session, user: User, cid: int) -> Conversation:
    conv = db.get(Conversation, cid)
    if not conv or not services.can_view_conversation(db, user, conv):
        raise HTTPException(404, "Conversation not found.")
    return conv


@router.get("/contacts")
def contacts(user: User = Depends(require("child")), db: Session = Depends(get_db)):
    rows = db.query(User).filter(User.role == "child", User.institution_id == user.institution_id, User.id != user.id,
                                 User.active == True).order_by(User.full_name).all()  # noqa: E712
    return [{"id": r.id, "name": r.full_name} for r in rows]


@router.post("/conversations")
def start(body: StartIn, user: User = Depends(require("child")), db: Session = Depends(get_db)):
    other = db.get(User, body.with_user_id)
    if not other or other.role != "child" or other.institution_id != user.institution_id or other.id == user.id:
        raise HTTPException(404, "That person isn't available.")
    a, b = sorted((user.id, other.id))
    conv = db.query(Conversation).filter(Conversation.user_a == a, Conversation.user_b == b).first()
    if not conv:
        conv = Conversation(user_a=a, user_b=b, created_at=utcnow())
        db.add(conv)
        db.commit()
    return {"id": conv.id, "name": other.full_name}


@router.get("/conversations")
def conversations(user: User = Depends(require("child")), db: Session = Depends(get_db)):
    convs = db.query(Conversation).filter((Conversation.user_a == user.id) | (Conversation.user_b == user.id)).all()
    out = []
    for c in convs:
        other = db.get(User, c.user_b if c.user_a == user.id else c.user_a)
        last = db.query(Message).filter(Message.conversation_id == c.id).order_by(Message.id.desc()).first()
        out.append({"id": c.id, "name": other.full_name, "last_at": last.created_at.isoformat() if last else None})
    return sorted(out, key=lambda x: x["last_at"] or "", reverse=True)


@router.get("/conversations/{cid}/messages")
def messages(cid: int, after: int = 0, user: User = Depends(require("child")), db: Session = Depends(get_db)):
    conv = _conv_or_404(db, user, cid)
    rows = (db.query(Message).filter(Message.conversation_id == conv.id, Message.id > after)
            .order_by(Message.id).limit(200).all())
    return {"restricted": is_restricted(user), "messages": [
        {"id": m.id, "mine": m.sender_id == user.id, "text": services.message_text(m),
         "image_url": f"/api/media/{m.id}" if m.image_path else None, "image_flagged": m.image_flagged,
         "created_at": m.created_at.isoformat()} for m in rows]}


@router.post("/conversations/{cid}/messages", dependencies=[Depends(limit_send)])
async def send(cid: int, text: str = Form(""), image: UploadFile | None = File(None),
               user: User = Depends(require("child")), db: Session = Depends(get_db)):
    conv = _conv_or_404(db, user, cid)
    data = await image.read(config.MAX_IMAGE_BYTES + 1) if image and image.filename else None
    return services.handle_message(db, user, conv, text, data, image.filename if image else "")


media = APIRouter(prefix="/api/media", tags=["media"])


@media.get("/{message_id}")
def get_image(message_id: int, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    m = db.get(Message, message_id)
    conv = db.get(Conversation, m.conversation_id) if m else None
    if not m or not m.image_path or not conv or not services.can_view_conversation(db, user, conv):
        raise HTTPException(404, "Image not found.")
    path = config.UPLOAD_DIR / m.image_path
    if not path.exists():
        raise HTTPException(404, "Image has expired.")
    if user.role != "child":
        audit(db, user, "view_image", f"message {m.id}", request)
    return Response(decrypt(path.read_bytes()), media_type="image/jpeg",
                    headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})
