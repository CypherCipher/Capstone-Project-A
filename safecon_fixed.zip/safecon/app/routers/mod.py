from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import config, services
from ..db import Alert, AuditLog, Message, User, Violation, utcnow
from ..deps import audit, get_db, require
from ..nlp import models
from .parent import child_json

router = APIRouter(prefix="/api/mod", tags=["moderator"])


class DecisionIn(BaseModel):
    decision: str   # confirm | dismiss


def _inst_children(db: Session, mod: User):
    return db.query(User).filter(User.role == "child", User.institution_id == mod.institution_id)


@router.get("/violations")
def violations(status: str = "pending", user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    kids = {c.id: c for c in _inst_children(db, user)}
    rows = (db.query(Violation).filter(Violation.child_id.in_(kids), Violation.status == status)
            .order_by(Violation.id.desc()).limit(100).all()) if kids else []
    return [{"id": v.id, "child": kids[v.child_id].full_name, "kind": v.kind, "reason": v.reason, "status": v.status,
             "message_id": v.message_id, "created_at": v.created_at.isoformat()} for v in rows]


@router.post("/violations/{vid}/review")
def review(vid: int, body: DecisionIn, request: Request, user: User = Depends(require("moderator")),
           db: Session = Depends(get_db)):
    if body.decision not in ("confirm", "dismiss"):
        raise HTTPException(400, "Decision must be confirm or dismiss.")
    v = db.get(Violation, vid)
    child = db.get(User, v.child_id) if v else None
    if not v or not child or child.institution_id != user.institution_id:
        raise HTTPException(404, "Not found.")
    if v.status != "pending":
        raise HTTPException(409, "Already reviewed.")
    services.review_violation(db, v, user, body.decision)
    db.commit()
    audit(db, user, f"violation_{body.decision}", f"violation {v.id}", request)
    return {"ok": True}


@router.get("/violations/{vid}/message")
def violation_message(vid: int, request: Request, user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    v = db.get(Violation, vid)
    child = db.get(User, v.child_id) if v else None
    m = db.get(Message, v.message_id) if v and v.message_id else None
    if not v or not child or child.institution_id != user.institution_id:
        raise HTTPException(404, "Not found.")
    audit(db, user, "view_flagged_messages", f"violation {v.id}", request)
    if not m:
        return {"expired": True}
    return {"expired": False, "text": services.message_text(m), "image_url": f"/api/media/{m.id}" if m.image_path else None,
            "image_flagged": m.image_flagged}


@router.get("/children")
def children(user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    return [child_json(db, c, with_history=False) for c in _inst_children(db, user).order_by(User.full_name)]


@router.post("/children/{cid}/lift")
def lift(cid: int, request: Request, user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    c = db.get(User, cid)
    if not c or c.role != "child" or c.institution_id != user.institution_id:
        raise HTTPException(404, "Not found.")
    c.restricted_until = None
    db.commit()
    audit(db, user, "lift_restriction", f"user {c.id}", request)
    return {"ok": True}


@router.get("/audit")
def audit_log(user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    users = {u.id: u for u in db.query(User).filter(User.institution_id == user.institution_id)}
    rows = db.query(AuditLog).filter(AuditLog.user_id.in_(users)).order_by(AuditLog.id.desc()).limit(150).all()
    return [{"id": r.id, "user": users[r.user_id].username, "role": users[r.user_id].role, "action": r.action,
             "target": r.target, "ip": r.ip, "created_at": r.created_at.isoformat()} for r in rows]


@router.get("/system")
def system(user: User = Depends(require("moderator")), db: Session = Depends(get_db)):
    levels = dict(db.query(Alert.risk_level, func.count()).group_by(Alert.risk_level).all())
    return {"models": models.STATUS,
            "counts": {"alerts_open": db.query(Alert).filter(Alert.status.in_(("new", "reviewing"))).count(),
                       "high": levels.get("High", 0), "medium": levels.get("Medium", 0),
                       "pending_violations": db.query(Violation).filter(Violation.status == "pending").count()},
            "retention": {"messages_days": config.MESSAGE_RETENTION_DAYS, "alerts_days": config.ALERT_RETENTION_DAYS},
            "warning_limit": config.WARNING_LIMIT, "restriction_hours": config.RESTRICTION_HOURS}
