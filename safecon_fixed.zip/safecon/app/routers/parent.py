from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..db import InterestCount, Notification, User, Violation, utcnow
from ..deps import audit, get_db, require
from ..security import USERNAME_RE, check_password_policy, hash_password

router = APIRouter(prefix="/api/parent", tags=["parent"])


class ChildIn(BaseModel):
    username: str
    password: str
    display_name: str = Field(min_length=2, max_length=60)


def child_json(db: Session, c: User, with_history: bool = True) -> dict:
    ints = db.query(InterestCount).filter(InterestCount.child_id == c.id).order_by(InterestCount.count.desc()).all()
    out = {"id": c.id, "username": c.username, "name": c.full_name, "stars": c.stars or 0,
           "warning_count": c.warning_count or 0,
           "restricted_until": c.restricted_until.isoformat() if c.restricted_until and c.restricted_until > utcnow() else None,
           "interests": [{"category": i.category, "count": i.count} for i in ints[:5]]}
    if with_history:
        vs = db.query(Violation).filter(Violation.child_id == c.id).order_by(Violation.id.desc()).limit(30).all()
        out["warnings"] = [{"id": v.id, "reason": v.reason, "status": v.status, "created_at": v.created_at.isoformat()} for v in vs]
    return out


@router.post("/children")
def add_child(body: ChildIn, request: Request, user: User = Depends(require("parent")), db: Session = Depends(get_db)):
    if not USERNAME_RE.match(body.username):
        raise HTTPException(400, "Username: 3-32 letters, numbers, dot, dash or underscore.")
    check_password_policy(body.password, body.username)
    if db.query(User).filter(User.username == body.username.lower()).first():
        raise HTTPException(409, "That username is taken.")
    child = User(username=body.username.lower(), password_hash=hash_password(body.password), role="child",
                 full_name=body.display_name.strip(), institution_id=user.institution_id, parent_id=user.id)
    db.add(child)
    db.commit()
    audit(db, user, "create_child", f"user {child.id}", request)
    return child_json(db, child)


@router.get("/children")
def children(user: User = Depends(require("parent")), db: Session = Depends(get_db)):
    return [child_json(db, c) for c in db.query(User).filter(User.parent_id == user.id).order_by(User.full_name)]


@router.get("/notifications")
def notifications(user: User = Depends(require("parent")), db: Session = Depends(get_db)):
    rows = db.query(Notification).filter(Notification.user_id == user.id).order_by(Notification.id.desc()).limit(50).all()
    return [{"id": n.id, "text": n.text, "read": n.read, "created_at": n.created_at.isoformat()} for n in rows]


@router.post("/notifications/read")
def mark_read(user: User = Depends(require("parent")), db: Session = Depends(get_db)):
    db.query(Notification).filter(Notification.user_id == user.id).update({"read": True})
    db.commit()
    return {"ok": True}
