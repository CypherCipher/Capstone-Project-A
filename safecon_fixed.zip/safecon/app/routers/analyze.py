import hmac

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field

from .. import config, services
from ..nlp import risk
from ..security import RateLimiter

router = APIRouter(prefix="/api", tags=["analyze"])
limit_analyze = RateLimiter(30, 60, "analyze")


class Msg(BaseModel):
    text: str = Field(max_length=config.MAX_TEXT_LEN)


class AnalyzeIn(BaseModel):
    messages: list[Msg] = Field(min_length=1, max_length=30)


@router.post("/analyze", dependencies=[Depends(limit_analyze)])
def analyze(body: AnalyzeIn, x_api_key: str = Header(default="")):
    """Service-to-service endpoint (API key). Analyzes a list of messages as one conversation window."""
    if not hmac.compare_digest(x_api_key, config.API_KEY):
        raise HTTPException(401, "Invalid API key.")
    texts = [m.text for m in body.messages]
    conf, source, sens, _ = services.analyze_window(texts)
    level = risk.assess(conf, bool(sens.kinds) or sens.requested, False)
    return {"risk_level": level, "grooming_confidence": round(conf, 4), "model_source": source,
            "indicators": risk.indicators(conf, sens.kinds, sens.requested, False),
            "latest_message_masked": sens.masked_text}
