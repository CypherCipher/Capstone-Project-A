"""Positive-communication star rewards with anti-gaming checks (rules + MiniLM similarity)."""
import difflib
import re
from datetime import timedelta

import numpy as np

from . import models
from ..db import Message, StarEvent, utcnow
from ..security import decrypt

POSITIVE_RULES = re.compile(
    r"\b(?:thank you|thanks|thank u|thx|please|sorry|i apologi[sz]e|excuse me|you(?:'re| are) welcome|appreciate|"
    r"well done|good job|congratulations|great job|no worries|that is kind|that was kind|nice of you|i respect)\b")
POSITIVE_PROTOS = ["thank you so much for helping me", "could you please help me with this",
                   "I am sorry about that, I did not mean it", "that is really kind of you", "great job, well done"]
COOLDOWN_S, DAILY_CAP, DUP_SIM, RECENT_N = 60, 10, 0.85, 5
_pos_emb = None


def is_positive(normalized: str) -> bool:
    global _pos_emb
    if POSITIVE_RULES.search(normalized):
        return True
    if len(normalized.split()) < 3:
        return False
    v = models.embed([normalized])
    if v is None:
        return False
    if _pos_emb is None:
        _pos_emb = models.embed(POSITIVE_PROTOS)
    return bool(float(np.max(_pos_emb @ v[0])) >= 0.62)


def award(db, child, normalized: str, message_id: int) -> tuple[bool, str]:
    """Returns (star_awarded, reason). Checks: genuine positive, cooldown, daily cap, duplicate/similar message."""
    if not is_positive(normalized):
        return False, "not positive"
    now = utcnow()
    events = (db.query(StarEvent).filter(StarEvent.child_id == child.id, StarEvent.created_at > now - timedelta(days=1))
              .order_by(StarEvent.id.desc()).all())
    if len(events) >= DAILY_CAP:
        return False, "daily cap"
    if events and (now - events[0].created_at).total_seconds() < COOLDOWN_S:
        return False, "cooldown"
    prev = []
    for ev in events[:RECENT_N]:
        m = db.get(Message, ev.message_id)
        if m:
            from .normalize import normalize
            prev.append(normalize(decrypt(m.ciphertext).decode()))
    if prev:
        if normalized in prev:
            return False, "duplicate"
        emb = models.embed([normalized] + prev)
        if emb is not None:
            if float(np.max(emb[1:] @ emb[0])) >= DUP_SIM:
                return False, "too similar"
        elif any(difflib.SequenceMatcher(None, normalized, p).ratio() >= 0.8 for p in prev):
            return False, "too similar"
    child.stars = (child.stars or 0) + 1
    db.add(StarEvent(child_id=child.id, message_id=message_id, created_at=now))
    return True, "awarded"
