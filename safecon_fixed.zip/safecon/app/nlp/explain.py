"""SHAP explanations: which words pushed the grooming score up (proposal section 4.3)."""
import logging
import re

import numpy as np

from .. import config
from . import models

log = logging.getLogger("safecon.explain")
_WORD = re.compile(r"\w+")


def _shap_top(text: str, k: int) -> list[dict]:
    import shap
    masker = shap.maskers.Text(r"\W+")
    explainer = shap.Explainer(models.text_batch, masker, silent=True)
    sv = explainer([text], max_evals=150, silent=True)[0]
    return [{"token": str(t).strip(), "weight": float(w)} for t, w in zip(sv.data, sv.values) if str(t).strip()]


def _occlusion_top(text: str, k: int) -> list[dict]:
    words = list(dict.fromkeys(_WORD.findall(text)))[:60]
    base = float(models.text_batch([text])[0])
    variants = [re.sub(rf"\b{re.escape(w)}\b", "", text) for w in words]
    probs = models.text_batch(variants) if variants else []
    return [{"token": w, "weight": base - float(p)} for w, p in zip(words, probs)]


def explain(window_text: str, k: int = 6) -> list[dict]:
    """Top-k words that increased the grooming score. Uses SHAP; falls back to word-removal (occlusion)."""
    text = window_text[-1200:]
    items: list[dict] = []
    if config.SHAP_ENABLED:
        try:
            items = _shap_top(text, k)
        except Exception as e:
            log.warning("SHAP failed (%s); using occlusion fallback", e)
    if not items:
        try:
            items = _occlusion_top(text, k)
        except Exception:
            return []
    items = [i for i in items if i["weight"] > 0.005]
    items.sort(key=lambda i: -i["weight"])
    return [{"token": i["token"], "weight": round(i["weight"], 3)} for i in items[:k]]
