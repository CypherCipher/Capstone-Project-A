"""Broad interest categories via MiniLM embeddings + cosine similarity (keyword fallback)."""
import re
import threading

import numpy as np

from . import models

CATEGORIES = {
    "sports":  ["I love playing football and basketball", "the match last night was amazing", "training for the swimming team"],
    "music":   ["I listen to this song all the time", "I play guitar and piano", "going to a concert"],
    "gaming":  ["I play video games on my console", "minecraft and roblox with friends", "I reached a new level in the game"],
    "books":   ["I am reading a really good book", "my favourite author wrote a new novel", "going to the library"],
    "art":     ["I like drawing and painting", "I made a sketch of my cat", "art class was fun today"],
    "science": ["I love space and planets", "our science experiment worked", "learning how computers and robots work"],
    "animals": ["my dog and cat are so cute", "I want a pet rabbit", "we went to the zoo"],
}
KEYWORDS = {
    "sports": r"\b(?:football|soccer|basketball|match|goal|team|swim\w*|tennis|cricket|gym|run\w*|sport\w*)\b",
    "music": r"\b(?:song|music|guitar|piano|band|concert|sing\w*|drum\w*|playlist)\b",
    "gaming": r"\b(?:game|games|gaming|minecraft|roblox|fortnite|console|level|xbox|playstation)\b",
    "books": r"\b(?:book|books|read\w*|novel|story|library|author)\b",
    "art": r"\b(?:draw\w*|paint\w*|art|sketch|colou?r\w*|craft)\b",
    "science": r"\b(?:science|space|planet\w*|robot\w*|experiment|computer\w*|coding|math)\b",
    "animals": r"\b(?:dog|cat|puppy|kitten|pet|rabbit|horse|zoo|animal\w*)\b",
}
THRESHOLD = 0.40
_proto = None
_lock = threading.Lock()


def _prototypes():
    global _proto
    with _lock:
        if _proto is None:
            names, sents = [], []
            for c, ss in CATEGORIES.items():
                names += [c] * len(ss)
                sents += ss
            emb = models.embed(sents)
            if emb is None:
                return None
            _proto = (np.array(names), emb)
        return _proto


def detect(text: str) -> str | None:
    """Return one broad category or None. Nothing about the conversation itself is kept."""
    if len(text.split()) < 3:
        return None
    proto = _prototypes()
    if proto is not None:
        names, emb = proto
        v = models.embed([text])
        if v is not None:
            sims = emb @ v[0]
            best = {}
            for n, s in zip(names, sims):
                best[n] = max(best.get(n, -1), float(s))
            cat, score = max(best.items(), key=lambda kv: kv[1])
            return cat if score >= THRESHOLD else None
    for cat, rx in KEYWORDS.items():
        if re.search(rx, text.lower()):
            return cat
    return None
