"""Explainable contextual risk rules (proposal section 4.3)."""
from .. import config

RANK = {"Low": 0, "Medium": 1, "High": 2}


def assess(text_conf: float, personal_info: bool, explicit_image: bool) -> str:
    """High : grooming conf >= 0.8, or >= 0.5 together with personal info or an explicit image
       Medium: conf in [0.5, 0.8), or personal info / explicit image on its own
       Low   : otherwise"""
    if text_conf >= config.HIGH_CONF:
        return "High"
    if text_conf >= config.MED_CONF and (personal_info or explicit_image):
        return "High"
    if text_conf >= config.MED_CONF or personal_info or explicit_image:
        return "Medium"
    return "Low"


def indicators(text_conf: float, kinds: list[str], requested: bool, explicit_image: bool) -> list[str]:
    out = []
    if text_conf >= config.MED_CONF:
        out.append("Possible grooming language detected")
    if kinds:
        out.append("Personal information detected (" + ", ".join(kinds) + ")")
    if requested:
        out.append("Personal information requested")
    if explicit_image:
        out.append("Sexually explicit image detected")
    return out
