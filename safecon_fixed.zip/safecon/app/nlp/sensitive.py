"""Sensitive-data detection and masking (proposal sections 2.1 and 4.3). Regex + spaCy NER, all local."""
import re
from dataclasses import dataclass, field

from .spacy_utils import get_nlp

PHONE = re.compile(r"(?<![\w])(?:\+?\d[\s\-.()]*){7,15}(?![\w])")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+|\b[\w.]+\s*(?:\(at\)|\[at\])\s*[\w.]+\s*(?:\(dot\)|\[dot\])\s*\w+", re.I)
URL = re.compile(r"https?://\S+|www\.\S+", re.I)
HANDLE = re.compile(
    r"\b(?:snap(?:chat)?|insta(?:gram)?|tiktok|discord|kik|whatsapp|telegram|username)\b\s*(?:is|:|-)?\s*@?[\w.]{3,}"
    r"|(?<![\w@])@[A-Za-z0-9_.]{3,}", re.I)
ADDRESS = re.compile(
    r"\b\d{1,5}\s+(?:[A-Za-z]+\s){1,3}(?:street|st|road|rd|avenue|ave|lane|ln|drive|dr|blvd|boulevard|court|ct)\b", re.I)
# NER hits only count when the person is talking about themselves (avoids flagging "I love Messi")
SELF_DISCLOSURE = re.compile(
    r"\b(?:my name is|i am called|i'm called|call me|i live (?:in|at|near|on)|i'm from|i am from|my school is|i go to|"
    r"my address|i stay (?:in|at|near)|my (?:last|full) name)\b", re.I)
MASK_LABELS = {"phone": "[phone hidden]", "email": "[email hidden]", "link": "[link hidden]",
               "username": "[username hidden]", "address": "[address hidden]",
               "name": "[name hidden]", "location": "[location hidden]"}

# Someone ASKING for personal info / contact / pictures (used by the risk engine)
REQUEST = re.compile(
    r"\b(?:what(?:'s| is)? your (?:phone|number|address|snapchat|instagram|whatsapp|email|full name|last name|school|username)|"
    r"where (?:do|did) you (?:live|go to school|stay)|(?:which|what) school (?:do|are) you|"
    r"(?:send|give|share|tell) (?:me )?(?:your )?(?:number|address|location|phone|snapchat|instagram|whatsapp|email))\b")
# NOTE: "how old are you?" is deliberately NOT here - alone it is a normal question (proposal section 1).


@dataclass
class SensitiveResult:
    masked_text: str
    kinds: list[str] = field(default_factory=list)       # e.g. ["phone", "name"]
    requested: bool = False                                # an info request was found


def detect(text: str, normalized: str | None = None) -> SensitiveResult:
    spans: list[tuple[int, int, str]] = []
    for kind, rx in (("email", EMAIL), ("link", URL), ("username", HANDLE), ("address", ADDRESS)):
        spans += [(m.start(), m.end(), kind) for m in rx.finditer(text)]
    for m in PHONE.finditer(text):
        if sum(c.isdigit() for c in m.group(0)) >= 7:
            spans.append((m.start(), m.end(), "phone"))

    if SELF_DISCLOSURE.search(text):
        nlp, has_ner = get_nlp()
        if has_ner:
            for ent in nlp(text).ents:
                if ent.label_ == "PERSON":
                    spans.append((ent.start_char, ent.end_char, "name"))
                elif ent.label_ in ("GPE", "LOC", "FAC"):
                    spans.append((ent.start_char, ent.end_char, "location"))
        else:  # no NER model: grab a capitalised word after the cue
            for m in re.finditer(r"(?:my name is|call me|i live (?:in|at|near)|i'm from|i am from)\s+([A-Z][a-z]+)", text):
                kind = "name" if re.match(r"(?i)my name|call me", m.group(0)) else "location"
                spans.append((m.start(1), m.end(1), kind))

    # drop overlaps (keep earlier/longer), then mask right-to-left
    spans.sort(key=lambda s: (s[0], -(s[1] - s[0])))
    merged: list[tuple[int, int, str]] = []
    for s in spans:
        if merged and s[0] < merged[-1][1]:
            continue
        merged.append(s)
    masked = text
    for start, end, kind in reversed(merged):
        masked = masked[:start] + MASK_LABELS[kind] + masked[end:]
    kinds = sorted({k for _, _, k in merged})
    requested = bool(REQUEST.search(normalized if normalized is not None else text.lower()))
    return SensitiveResult(masked, kinds, requested)
