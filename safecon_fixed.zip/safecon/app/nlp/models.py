"""Loads the three local Hugging Face models in a background thread.
   text  : erikaecl/hansen-grooming-distilbert  (DistilBERT grooming classifier, from the proposal's baseline)
   image : Falconsai/nsfw_image_detection        (Vision Transformer, Normal vs NSFW)
   embed : sentence-transformers/all-MiniLM-L6-v2 (interests + star rewards)
If a model can't load (no internet, no torch...), a clearly-labelled fallback is used so the app keeps working."""
import logging
import threading

import numpy as np

from .. import config
from . import lexicon

log = logging.getLogger("safecon.models")

STATUS = {
    "text":  {"model": config.TEXT_MODEL_ID,  "state": "not loaded", "real": False, "detail": ""},
    "image": {"model": config.IMAGE_MODEL_ID, "state": "not loaded", "real": False, "detail": ""},
    "embed": {"model": config.EMBED_MODEL_ID, "state": "not loaded", "real": False, "detail": ""},
}
_text_pipe = _image_pipe = _embedder = None
_grooming_label = None
_lock = threading.Lock()


def _set(name, state, real=False, detail=""):
    STATUS[name].update(state=state, real=real, detail=detail[:200])


def _pick_grooming_label(id2label: dict) -> str:
    labels = list(id2label.values())
    if config.TEXT_GROOMING_LABEL:
        return config.TEXT_GROOMING_LABEL
    for lab in labels:
        l = lab.lower()
        if ("groom" in l or "predator" in l or "unsafe" in l) and not l.startswith(("non", "not", "no_", "no ", "safe")):
            return lab
    if "LABEL_1" in labels:
        return "LABEL_1"
    return labels[-1]


def load_all() -> None:
    if config.MODELS_MODE == "off":
        for n in STATUS:
            _set(n, "disabled (SAFECON_MODELS=off)")
        return
    global _text_pipe, _image_pipe, _embedder, _grooming_label
    try:
        from transformers import pipeline
    except Exception as e:  # torch / transformers missing
        for n in ("text", "image"):
            _set(n, "fallback", detail=f"transformers unavailable: {e}")
    else:
        try:
            _set("text", "loading")
            p = pipeline("text-classification", model=config.TEXT_MODEL_ID, device=-1)
            p.tokenizer.truncation_side = "left"      # keep the MOST RECENT messages when text > 512 tokens
            _grooming_label = _pick_grooming_label(p.model.config.id2label)
            _text_pipe = p
            _set("text", "ready", True, f"grooming label = {_grooming_label}")
        except Exception as e:
            _set("text", "fallback", detail=str(e))
        try:
            _set("image", "loading")
            _image_pipe = pipeline("image-classification", model=config.IMAGE_MODEL_ID, device=-1)
            _set("image", "ready", True)
        except Exception as e:
            _set("image", "fallback", detail=str(e))
    try:
        _set("embed", "loading")
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer(config.EMBED_MODEL_ID, device="cpu")
        _set("embed", "ready", True)
    except Exception as e:
        _set("embed", "fallback", detail=str(e))


def start_background_load() -> threading.Thread:
    t = threading.Thread(target=load_all, name="model-loader", daemon=True)
    t.start()
    return t


# ---------------------------------------------------------------- text
def text_source() -> str:
    return f"distilbert:{config.TEXT_MODEL_ID}" if _text_pipe else "fallback-rules"


def _grooming_probs(texts: list[str]) -> np.ndarray:
    out = _text_pipe(texts, top_k=None, truncation=True, max_length=512, batch_size=16)
    if out and isinstance(out[0], dict):
        out = [out]
    return np.array([next((d["score"] for d in res if d["label"] == _grooming_label), 0.0) for res in out])


def text_batch(texts: list[str]) -> np.ndarray:
    """Grooming probability for each text (used by SHAP)."""
    if _text_pipe:
        with _lock:
            return _grooming_probs(texts)
    return np.array([lexicon.score(t)[0] for t in texts])


def predict_text(window_text: str) -> tuple[float, str]:
    return float(text_batch([window_text])[0]), text_source()


# ---------------------------------------------------------------- image
def predict_image(img, filename: str = "") -> tuple[float, str]:
    """Return (probability the image is NSFW, source)."""
    if _image_pipe:
        with _lock:
            res = _image_pipe(img.convert("RGB"), top_k=None)   # pipeline's processor resizes + normalises
        nsfw = next((d["score"] for d in res if "nsfw" in d["label"].lower()), 0.0)
        return float(nsfw), f"vit:{config.IMAGE_MODEL_ID}"
    # DEMO STUB: lets you test the explicit-image path without the model. Name a file "demo-explicit.jpg".
    return (0.99 if "demo-explicit" in filename.lower() else 0.01), "demo-stub"


# ---------------------------------------------------------------- embeddings
def embed(texts: list[str]):
    """Normalised sentence embeddings, or None when MiniLM isn't available."""
    if not _embedder:
        return None
    with _lock:
        return _embedder.encode(texts, normalize_embeddings=True, show_progress_bar=False)
