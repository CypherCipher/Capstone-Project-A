"""Slang / emoji / obfuscation normalization (proposal section 4.1).
Tools: Python, Regex, spaCy, custom slang dictionary, emoji library."""
import re

import emoji

from .spacy_utils import get_nlp

SLANG = {
    "wyd": "what are you doing", "rn": "right now", "hmu": "hit me up", "idk": "i do not know",
    "u": "you", "ur": "your", "r": "are", "y": "why", "k": "okay", "kk": "okay", "omg": "oh my god",
    "brb": "be right back", "btw": "by the way", "tbh": "to be honest", "lol": "laughing out loud",
    "pls": "please", "plz": "please", "thx": "thanks", "ty": "thank you", "tysm": "thank you so much",
    "dm": "direct message", "pm": "private message", "asl": "age sex location",
    "pic": "picture", "pics": "pictures", "snap": "snapchat", "insta": "instagram", "ig": "instagram",
    "gf": "girlfriend", "bf": "boyfriend", "irl": "in real life", "ily": "i love you", "jk": "just kidding",
    "nvm": "never mind", "gtg": "got to go", "ttyl": "talk to you later", "cuz": "because", "bc": "because",
    "ppl": "people", "sup": "what is up", "wanna": "want to", "gonna": "going to", "gotta": "got to",
    "tmrw": "tomorrow", "2moro": "tomorrow", "2day": "today", "2nite": "tonight", "b4": "before",
    "l8r": "later", "thru": "through", "ya": "you", "yall": "you all", "sry": "sorry", "srsly": "seriously",
    "mins": "minutes", "xoxo": "hugs and kisses", "ofc": "of course", "fr": "for real", "ngl": "not gonna lie",
    "lmk": "let me know", "fyi": "for your information", "imo": "in my opinion", "np": "no problem",
    "thnx": "thanks", "wat": "what", "wut": "what", "wen": "when", "wer": "where", "num": "number",
    "addy": "address", "nudes": "nude pictures", "nude": "nude", "sext": "sexual text",
}
LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"})
_SPACED = re.compile(r"\b(?:[a-z][\s.\-_*]){3,}[a-z]\b")        # "s e c r e t" / "s.e.c.r.e.t"
_REPEAT = re.compile(r"([a-z])\1{2,}")                           # "heyyyy" -> "heyy"
_ASL = re.compile(r"\ba\s*/\s*s\s*/\s*l\b")
_MIXED = re.compile(r"(?=\w*[a-z])(?=\w*[0-9@$])[a-z0-9@$]{3,}")  # token mixing letters + leet chars
_PLACEHOLDER = re.compile(r"\[[a-z ]+ hidden\]")


def _demojize(text: str) -> str:
    out = emoji.demojize(text, delimiters=(" ", " "))
    return out.replace("_", " ").replace("-", " ")


def _unleet(match: re.Match) -> str:
    tok = match.group(0)
    if re.fullmatch(r"\d+", tok):
        return tok
    return tok.translate(LEET)


def normalize(text: str) -> str:
    """Return readable lowercase text with slang expanded, emojis described, simple obfuscation undone."""
    t = text.lower()
    t = _demojize(t)
    t = _ASL.sub("age sex location", t)
    t = _SPACED.sub(lambda m: re.sub(r"[\s.\-_*]", "", m.group(0)), t)
    t = _REPEAT.sub(r"\1\1", t)
    keep = {m.group(0): f"\0{i}\0" for i, m in enumerate(_PLACEHOLDER.finditer(t))}
    for k, v in keep.items():
        t = t.replace(k, v)
    t = _MIXED.sub(_unleet, t)
    nlp, _ = get_nlp()
    tokens = [SLANG.get(tok.text, tok.text) if not tok.is_space else " " for tok in nlp.make_doc(t)]
    t = " ".join(x for x in tokens if x.strip())
    t = re.sub(r"\s+([,.!?;:])", r"\1", t)
    for k, v in keep.items():
        t = t.replace(v, k)
    return re.sub(r"\s+", " ", t).strip()
