"""Rule-based stand-in used ONLY while the real Hugging Face text model is unavailable.
It scores a normalized conversation window with grooming-stage cues so the whole app still works offline."""
import re

CUES = {
    "secrecy":   (0.50, r"\b(?:our secret|keep (?:this|it) (?:between us|secret|quiet)|don'?t tell (?:your )?(?:parents|mom|dad|mum|anyone|anybody)|"
                        r"do not tell (?:your )?(?:parents|mom|dad|mum|anyone|anybody)|delete (?:this|the) (?:chat|messages?)|just between us|no one (?:needs|has) to know)\b"),
    "isolation": (0.30, r"\b(?:are you alone|are your parents (?:home|there|around|out)|home alone|when (?:are|will) your parents)\b"),
    "meet":      (0.30, r"\b(?:meet (?:me|up)|come to my (?:place|house)|pick you up|come over|see you in person|visit you)\b"),
    "sexual":    (0.50, r"\b(?:nude|naked|sexy|sexual|touch you|kiss you|your body|bra|underwear)\b"),
    "picture":   (0.30, r"\b(?:send (?:me )?(?:a |your )?(?:picture|photo|selfie|pictures)|what do you look like|show me (?:you|yourself))\b"),
    "flattery":  (0.20, r"\b(?:so mature|more mature than|special to me|you are special|nobody understands you like|i understand you|my special)\b"),
    "gifts":     (0.20, r"\b(?:buy you|gift for you|i will pay|send you money|present for you)\b"),
    "platform":  (0.20, r"\b(?:add me on|what is your (?:number|snapchat|whatsapp|instagram)|text me|call me|move to (?:snapchat|whatsapp|telegram))\b"),
    "age_probe": (0.12, r"\b(?:how old are you|what is your age|age sex location)\b"),
}
_COMPILED = {k: (w, re.compile(p)) for k, (w, p) in CUES.items()}


def score(text: str) -> tuple[float, list[str]]:
    """Combine cue weights as 1 - prod(1 - w). One age question alone stays low; several stages stack up."""
    t = text.lower()
    remaining, hits = 1.0, []
    for name, (w, rx) in _COMPILED.items():
        if rx.search(t):
            remaining *= 1 - w
            hits.append(name)
    return round(1 - remaining, 4), hits
