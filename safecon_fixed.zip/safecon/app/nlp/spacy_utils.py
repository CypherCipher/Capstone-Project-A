import functools
import logging

log = logging.getLogger("safecon.nlp")


@functools.lru_cache(maxsize=1)
def get_nlp():
    """spaCy pipeline. Falls back to a blank English tokenizer (no NER) if the model is missing."""
    import spacy
    try:
        return spacy.load("en_core_web_sm"), True
    except OSError:
        log.warning("spaCy model en_core_web_sm not found (run: python -m spacy download en_core_web_sm). NER disabled.")
        return spacy.blank("en"), False
