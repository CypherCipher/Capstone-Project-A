"""The message pipeline: validate -> sanitize -> normalize -> sensitive data -> store encrypted ->
conversation window -> DistilBERT + ViT -> XAI risk rules -> alert / possible violation / interests / stars."""
import io
import re
import uuid
from datetime import timedelta

from fastapi import HTTPException
from PIL import Image, UnidentifiedImageError
from sqlalchemy.orm import Session

from . import config
from .db import (Alert, Conversation, InterestCount, Message, Notification, User, Violation, utcnow)
from .deps import is_restricted
from .nlp import explain, interests, models, risk, sensitive, stars
from .nlp.normalize import normalize
from .security import decrypt, encrypt, sec_log

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(text: str) -> str:
    text = _CTRL.sub("", (text or "")).strip()
    if len(text) > config.MAX_TEXT_LEN:
        raise HTTPException(400, f"Message is too long (max {config.MAX_TEXT_LEN} characters).")
    return text


def read_image(data: bytes, filename: str):
    """Validate, strip metadata (EXIF/GPS) by re-encoding, return (PIL image, clean JPEG bytes)."""
    if len(data) > config.MAX_IMAGE_BYTES:
        raise HTTPException(400, "Image is too large (max 5 MB).")
    try:
        probe = Image.open(io.BytesIO(data))
        probe.verify()
        img = Image.open(io.BytesIO(data))
        if img.format not in ("JPEG", "PNG", "WEBP"):
            raise HTTPException(400, "Only JPEG, PNG or WEBP images are allowed.")
        if img.width * img.height > 40_000_000:
            raise HTTPException(400, "Image dimensions are too large.")
        img = img.convert("RGB")
    except (UnidentifiedImageError, OSError):
        raise HTTPException(400, "That file is not a valid image.")
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=88)
    return img, buf.getvalue()


def participants(conv: Conversation) -> list[int]:
    return [conv.user_a, conv.user_b]


def can_view_conversation(db: Session, user: User, conv: Conversation) -> bool:
    """Participants, the parent of a participant, or a moderator of the same institution."""
    ids = participants(conv)
    if user.role == "child":
        return user.id in ids
    kids = db.query(User).filter(User.id.in_(ids)).all()
    if user.role == "parent":
        return any(k.parent_id == user.id for k in kids)
    if user.role == "moderator":
        return any(k.institution_id == user.institution_id for k in kids)
    return False


def window(db: Session, conv_id: int, upto_id: int | None = None, n: int = config.WINDOW_MESSAGES) -> list[Message]:
    q = db.query(Message).filter(Message.conversation_id == conv_id)
    if upto_id:
        q = q.filter(Message.id <= upto_id)
    return list(reversed(q.order_by(Message.id.desc()).limit(n).all()))


def message_text(m: Message) -> str:
    return decrypt(m.ciphertext).decode("utf-8", "replace")


def _notify_parents(db: Session, child_ids: list[int], text: str):
    for pid in {c.parent_id for c in db.query(User).filter(User.id.in_(child_ids)) if c.parent_id}:
        db.add(Notification(user_id=pid, text=text[:200], created_at=utcnow()))


def _upsert_alert(db: Session, conv: Conversation, msg: Message, level: str, text_conf: float,
                  image_conf: float | None, inds: list[str], window_text: str, source: str) -> Alert | None:
    now = utcnow()
    last = (db.query(Alert).filter(Alert.conversation_id == conv.id,
                                   Alert.created_at > now - timedelta(minutes=config.ALERT_MERGE_MINUTES))
            .order_by(Alert.id.desc()).first())
    conf = max(text_conf, image_conf or 0.0)
    if last and risk.RANK[level] <= risk.RANK[last.risk_level]:
        if last.status not in ("new", "reviewing"):
            return None                                   # already handled by a moderator; don't spam
        last.indicators = sorted(set(last.indicators or []) | set(inds))
        last.text_conf = max(last.text_conf or 0, text_conf)
        if image_conf is not None:
            last.image_conf = max(last.image_conf or 0, image_conf)
        last.confidence = max(last.confidence or 0, conf)
        last.message_id, last.trigger_user_id, last.updated_at = msg.id, msg.sender_id, now
        return last
    alert = Alert(conversation_id=conv.id, message_id=msg.id, trigger_user_id=msg.sender_id, risk_level=level,
                  text_conf=text_conf, image_conf=image_conf, confidence=conf, indicators=inds,
                  explanation=explain.explain(window_text) if text_conf >= config.MED_CONF else [],
                  model_source=source, status="new", created_at=now, updated_at=now,
                  expires_at=now + timedelta(days=config.ALERT_RETENTION_DAYS))
    db.add(alert)
    return alert


def analyze_window(texts: list[str], current_normalized: str | None = None, current_raw: str | None = None):
    """Pure analysis used by both the chat pipeline and the /api/analyze endpoint."""
    norm_window = [normalize(t) for t in texts]
    window_text = "\n".join(norm_window)
    conf, source = models.predict_text(window_text)
    cur_norm = current_normalized if current_normalized is not None else (norm_window[-1] if norm_window else "")
    sens = sensitive.detect(current_raw if current_raw is not None else (texts[-1] if texts else ""), cur_norm)
    return conf, source, sens, window_text


def handle_message(db: Session, sender: User, conv: Conversation, text: str, image_bytes: bytes | None,
                   image_name: str = "") -> dict:
    if is_restricted(sender):
        raise HTTPException(403, "Your chat is paused for now. A moderator or your parent can restore it.")
    text = clean_text(text)
    if not text and not image_bytes:
        raise HTTPException(400, "Write a message or add a picture.")

    # --- image path ---
    img_score = None
    img_source = None
    img_path = None
    explicit = False
    if image_bytes:
        pil, clean_jpeg = read_image(image_bytes, image_name)
        img_score, img_source = models.predict_image(pil, image_name)
        explicit = img_score >= config.IMAGE_NSFW_THRESHOLD
        img_path = f"{uuid.uuid4().hex}.bin"
        (config.UPLOAD_DIR / img_path).write_bytes(encrypt(clean_jpeg))

    # --- text path: normalize + detect/mask personal info BEFORE storing ---
    norm = normalize(text) if text else ""
    sens = sensitive.detect(text, norm) if text else sensitive.SensitiveResult("", [], False)
    now = utcnow()
    msg = Message(conversation_id=conv.id, sender_id=sender.id, ciphertext=encrypt(sens.masked_text.encode()),
                  image_path=img_path, image_flagged=explicit, created_at=now,
                  expires_at=now + timedelta(days=config.MESSAGE_RETENTION_DAYS))
    db.add(msg)
    db.flush()

    # --- conversation window + models ---
    msgs = window(db, conv.id, msg.id)
    window_text = "\n".join(normalize(message_text(m)) for m in msgs if m.ciphertext and message_text(m))
    text_conf, text_source = models.predict_text(window_text) if window_text else (0.0, models.text_source())

    kinds = sens.kinds
    pi_flag = bool(kinds) or sens.requested
    level = risk.assess(text_conf, pi_flag, explicit)
    inds = risk.indicators(text_conf, kinds, sens.requested, explicit)
    alert_made = False
    if level != "Low":
        source = text_source + (f" + {img_source}" if img_source else "")
        a = _upsert_alert(db, conv, msg, level, text_conf, img_score if image_bytes else None, inds, window_text, source)
        alert_made = a is not None

    # --- possible violations (only for things the CHILD sent; a moderator must confirm) ---
    if kinds:
        db.add(Violation(child_id=sender.id, message_id=msg.id, kind="personal_info",
                         reason="Shared personal information (" + ", ".join(kinds) + ")", created_at=now))
    if explicit:
        db.add(Violation(child_id=sender.id, message_id=msg.id, kind="explicit_image",
                         reason="Sent a sexually explicit image", created_at=now))

    # --- interests + stars (text only) ---
    star = False
    if text:
        cat = interests.detect(norm)
        if cat:
            row = db.get(InterestCount, (sender.id, cat))
            if row:
                row.count += 1
            else:
                db.add(InterestCount(child_id=sender.id, category=cat, count=1))
        star, _ = stars.award(db, sender, norm, msg.id)

    db.commit()
    sec_log("message_processed", conv=conv.id, risk=level, alert=alert_made)   # no message text in logs
    return {"id": msg.id, "masked": kinds, "star": star, "image_flagged": explicit,
            "text": sens.masked_text, "created_at": now.isoformat()}


def purge_expired(db: Session) -> dict:
    """Retention: chat 30 days, alerts 90 days (values from config)."""
    now = utcnow()
    old = db.query(Message).filter(Message.expires_at < now).all()
    for m in old:
        if m.image_path:
            (config.UPLOAD_DIR / m.image_path).unlink(missing_ok=True)
        db.delete(m)
    n_alerts = db.query(Alert).filter(Alert.expires_at < now).delete()
    db.commit()
    return {"messages": len(old), "alerts": n_alerts}


def review_violation(db: Session, v: Violation, reviewer: User, decision: str) -> None:
    child = db.get(User, v.child_id)
    v.status = "confirmed" if decision == "confirm" else "dismissed"
    v.reviewer_id, v.reviewed_at = reviewer.id, utcnow()
    if decision != "confirm":
        return
    child.warning_count = (child.warning_count or 0) + 1
    if child.parent_id:
        db.add(Notification(user_id=child.parent_id, created_at=utcnow(),
                            text=f"Warning confirmed for {child.full_name}: {v.reason}"))
    if child.warning_count >= config.WARNING_LIMIT:
        child.restricted_until = utcnow() + timedelta(hours=config.RESTRICTION_HOURS)
        child.warning_count = 0
        if child.parent_id:
            db.add(Notification(user_id=child.parent_id, created_at=utcnow(),
                                text=f"{child.full_name}'s chat is paused for {config.RESTRICTION_HOURS} hours after "
                                     f"{config.WARNING_LIMIT} confirmed warnings."))
        sec_log("child_restricted", child=child.id, by=reviewer.id)
