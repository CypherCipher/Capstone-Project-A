import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import config
from .db import SessionLocal, init_db
from .nlp import models
from .routers import alerts, analyze, auth, chat, mod, parent
from .services import purge_expired

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("safecon")


async def _retention_loop():
    while True:
        try:
            with SessionLocal() as db:
                r = purge_expired(db)
                if r["messages"] or r["alerts"]:
                    log.info("retention purge: %s", r)
        except Exception:
            log.exception("retention purge failed")
        await asyncio.sleep(3600)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    models.start_background_load()          # models load in the background; fallbacks are used until ready
    task = asyncio.create_task(_retention_loop())
    yield
    task.cancel()


app = FastAPI(title="SafeCon (prototype)", lifespan=lifespan, docs_url="/api/docs", redoc_url=None, openapi_url="/api/openapi.json")

SECURITY_HEADERS = {
    "Content-Security-Policy": "default-src 'self'; img-src 'self' blob: data:; style-src 'self'; script-src 'self'; "
                               "frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
}


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # CSRF defence on top of SameSite=Strict: state-changing API calls must carry our custom header
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.url.path.startswith("/api/") \
            and request.url.path != "/api/analyze" and request.headers.get("x-requested-with") != "SafeCon":
        return JSONResponse({"detail": "Missing request header."}, status_code=403, headers=SECURITY_HEADERS)
    response = await call_next(request)
    path = request.url.path
    if path.startswith("/api/docs") or path.startswith("/api/openapi"):
        return response                      # Swagger UI needs inline scripts; keep it dev-only
    for k, v in SECURITY_HEADERS.items():
        response.headers.setdefault(k, v)
    if config.COOKIE_SECURE:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    if path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


for r in (auth.router, chat.router, chat.media, alerts.router, parent.router, mod.router, analyze.router):
    app.include_router(r)


@app.get("/")
def root():
    return RedirectResponse("/index.html")


app.mount("/", StaticFiles(directory=config.STATIC_DIR, html=True), name="static")
