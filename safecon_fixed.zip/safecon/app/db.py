from datetime import datetime, timedelta, timezone

from sqlalchemy import (JSON, Boolean, Column, DateTime, Float, Integer, LargeBinary,
                        String, create_engine)
from sqlalchemy.orm import declarative_base, sessionmaker

from .config import DB_URL


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
Base = declarative_base()


class Institution(Base):
    __tablename__ = "institutions"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), unique=True, nullable=False)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(32), unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String(12), nullable=False)            # child | parent | moderator
    full_name = Column(String(60), nullable=False)
    institution_id = Column(Integer, index=True)
    parent_id = Column(Integer, index=True)              # for child accounts
    active = Column(Boolean, default=True)
    failed_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)
    mfa_secret = Column(String)
    mfa_enabled = Column(Boolean, default=False)
    warning_count = Column(Integer, default=0)           # confirmed warnings since last restriction
    restricted_until = Column(DateTime)
    stars = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)


class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True)
    user_a = Column(Integer, index=True, nullable=False)
    user_b = Column(Integer, index=True, nullable=False)
    created_at = Column(DateTime, default=utcnow)


class Message(Base):
    """Chat storage. Text and images are encrypted (AES-256-GCM) and deleted after 30 days."""
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, index=True, nullable=False)
    sender_id = Column(Integer, index=True, nullable=False)
    ciphertext = Column(LargeBinary, nullable=False)
    image_path = Column(String)
    image_flagged = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow, index=True)
    expires_at = Column(DateTime, index=True)


class Alert(Base):
    """Holds NO message text or images - only risk metadata (deleted after 90 days)."""
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, index=True, nullable=False)
    message_id = Column(Integer)            # last flagged message (looked up in encrypted chat storage)
    trigger_user_id = Column(Integer)       # sender of the latest flagged message
    risk_level = Column(String(8), nullable=False)
    text_conf = Column(Float, default=0.0)
    image_conf = Column(Float)
    confidence = Column(Float, default=0.0)
    indicators = Column(JSON, default=list)
    explanation = Column(JSON, default=list)   # SHAP token weights
    model_source = Column(String(40))
    status = Column(String(12), default="new", index=True)   # new|reviewing|confirmed|dismissed|escalated
    reviewer_id = Column(Integer)
    note = Column(String(200))
    created_at = Column(DateTime, default=utcnow, index=True)
    updated_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, index=True)


class Violation(Base):
    """A *possible* violation by a child (shared personal info / explicit image). Moderator must confirm."""
    __tablename__ = "violations"
    id = Column(Integer, primary_key=True)
    child_id = Column(Integer, index=True, nullable=False)
    message_id = Column(Integer)
    kind = Column(String(20), nullable=False)    # personal_info | explicit_image
    reason = Column(String(120), nullable=False)
    status = Column(String(10), default="pending", index=True)  # pending|confirmed|dismissed
    reviewer_id = Column(Integer)
    created_at = Column(DateTime, default=utcnow)
    reviewed_at = Column(DateTime)


class InterestCount(Base):
    """Only broad interest categories are kept - never conversation details."""
    __tablename__ = "interests"
    child_id = Column(Integer, primary_key=True)
    category = Column(String(20), primary_key=True)
    count = Column(Integer, default=0)


class StarEvent(Base):
    __tablename__ = "star_events"
    id = Column(Integer, primary_key=True)
    child_id = Column(Integer, index=True)
    message_id = Column(Integer)
    created_at = Column(DateTime, default=utcnow)


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    text = Column(String(200))
    read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    action = Column(String(40))
    target = Column(String(80))
    ip = Column(String(45))
    created_at = Column(DateTime, default=utcnow, index=True)


def init_db():
    Base.metadata.create_all(engine)
