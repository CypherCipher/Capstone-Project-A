import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from app.main import app
from app.nlp.normalize import normalize
from app.nlp import sensitive, risk

H = {"X-Requested-With": "SafeCon"}
PW = "Correct-Horse-9"


@pytest.fixture(scope="module")
def world():
    with TestClient(app) as anon:
        def client():
            return TestClient(app, headers=H)
        c = {}
        for role, user in (("parent", "parent1"), ("parent", "parent2"), ("moderator", "mod1")):
            cl = client()
            r = cl.post("/api/auth/register", json={"username": user, "password": PW, "full_name": user.upper(),
                                                      "role": role, "institution": "Test School" if user != "parent2" else "Other School"})
            assert r.status_code == 200, r.text
            assert cl.post("/api/auth/login", json={"username": user, "password": PW}).status_code == 200
            c[user] = cl
        for kid in ("kid1", "kid2"):
            r = c["parent1"].post("/api/parent/children", json={"username": kid, "password": PW, "display_name": kid.title()})
            assert r.status_code == 200, r.text
            cl = client()
            assert cl.post("/api/auth/login", json={"username": kid, "password": PW}).status_code == 200
            c[kid] = cl
        yield c


def _conv(world):
    contacts = world["kid1"].get("/api/chat/contacts").json()
    kid2 = next(x for x in contacts if x["name"] == "Kid2")
    cid = world["kid1"].post("/api/chat/conversations", json={"with_user_id": kid2["id"]}).json()["id"]
    return cid


def test_normalization():
    assert "what are you doing right now" in normalize("wyd rn")
    assert "smiling" in normalize("hi 😊")
    assert "secret" in normalize("our s3cret")
    assert normalize("heyyyyy") == "heyy"


def test_sensitive_masking():
    r = sensitive.detect("call me on 0501234567 or mail bob@example.com")
    assert "phone" in r.kinds and "email" in r.kinds and "0501234567" not in r.masked_text
    assert not sensitive.detect("I love Messi so much").kinds          # NER alone does not flag
    assert not sensitive.detect("how old are you", "how old are you").requested
    assert sensitive.detect("what is your address", "what is your address").requested


def test_risk_rules():
    assert risk.assess(0.85, False, False) == "High"
    assert risk.assess(0.55, True, False) == "High"
    assert risk.assess(0.55, False, False) == "Medium"
    assert risk.assess(0.1, False, True) == "Medium"
    assert risk.assess(0.1, False, False) == "Low"


def test_csrf_header_required(world):
    with TestClient(app) as raw:
        assert raw.post("/api/auth/logout").status_code == 403


def test_unauthenticated_and_roles(world):
    with TestClient(app) as raw:
        assert raw.get("/api/alerts").status_code == 401
    assert world["kid1"].get("/api/alerts").status_code == 403
    assert world["parent1"].get("/api/mod/audit").status_code == 403


def test_one_age_question_is_not_an_alert(world):
    cid = _conv(world)
    r = world["kid2"].post(f"/api/chat/conversations/{cid}/messages", data={"text": "how old are you?"})
    assert r.status_code == 200
    assert world["mod1"].get("/api/alerts").json() == []


def test_grooming_sequence_creates_alert_and_access_control(world):
    cid = _conv(world)
    kid2 = world["kid2"]
    for t in ("you are so mature for your age", "are you alone? are your parents home?",
              "dont tell ur parents, this is our secret", "send me a pic and meet me tomorrow"):
        assert kid2.post(f"/api/chat/conversations/{cid}/messages", data={"text": t}).status_code == 200
    alerts = world["mod1"].get("/api/alerts").json()
    assert alerts and alerts[0]["risk_level"] == "High"
    a = alerts[0]
    assert "Possible grooming language detected" in a["indicators"]
    assert any(e["token"] for e in a["explanation"])
    assert "text" not in a                                              # alerts never carry message text
    # parent of the children sees it, parent of another institution does not
    assert world["parent1"].get("/api/alerts").json()
    assert world["parent2"].get("/api/alerts").json() == []
    assert world["parent2"].get(f"/api/alerts/{a['id']}").status_code == 404
    msgs = world["parent1"].get(f"/api/alerts/{a['id']}/messages").json()["messages"]
    assert any("secret" in m["text"] for m in msgs)
    # moderator workflow + audit trail
    r = world["mod1"].patch(f"/api/alerts/{a['id']}", json={"status": "confirmed", "note": "checked"})
    assert r.json()["status"] == "confirmed"
    assert world["parent1"].patch(f"/api/alerts/{a['id']}", json={"status": "dismissed"}).status_code == 403
    actions = [x["action"] for x in world["mod1"].get("/api/mod/audit").json()]
    assert "alert_confirmed" in actions and "view_flagged_messages" not in [] 
    assert any(n["text"] for n in world["parent1"].get("/api/parent/notifications").json())


def test_personal_info_is_masked_and_warning_flow(world):
    cid = _conv(world)
    kid1 = world["kid1"]
    r = kid1.post(f"/api/chat/conversations/{cid}/messages", data={"text": "my number is 050 123 4567"}).json()
    assert "050" not in r["text"] and "phone" in r["masked"]
    for _ in range(2):
        kid1.post(f"/api/chat/conversations/{cid}/messages", data={"text": "text me at kid@example.com"})
    pend = world["mod1"].get("/api/mod/violations").json()
    assert len(pend) >= 3
    for v in pend[:3]:
        assert world["mod1"].post(f"/api/mod/violations/{v['id']}/review", json={"decision": "confirm"}).status_code == 200
    r = kid1.post(f"/api/chat/conversations/{cid}/messages", data={"text": "hello"})
    assert r.status_code == 403                                         # restricted after 3 confirmed warnings
    kid = next(c for c in world["parent1"].get("/api/parent/children").json() if c["name"] == "Kid1")
    assert kid["restricted_until"] and len(kid["warnings"]) >= 3
    assert world["mod1"].post(f"/api/mod/children/{kid['id']}/lift").status_code == 200
    assert kid1.post(f"/api/chat/conversations/{cid}/messages", data={"text": "hello again"}).status_code == 200


def test_stars_and_anti_spam(world):
    cid = _conv(world)
    kid2 = world["kid2"]
    first = kid2.post(f"/api/chat/conversations/{cid}/messages", data={"text": "thank you so much for helping me"}).json()
    again = kid2.post(f"/api/chat/conversations/{cid}/messages", data={"text": "thank you so much for helping me"}).json()
    assert first["star"] is True and again["star"] is False             # cooldown / duplicate


def test_image_pipeline(world):
    cid = _conv(world)
    buf = io.BytesIO()
    Image.new("RGB", (64, 64), "red").save(buf, "PNG")
    ok = world["kid2"].post(f"/api/chat/conversations/{cid}/messages", data={"text": ""},
                            files={"image": ("cat.png", buf.getvalue(), "image/png")})
    assert ok.status_code == 200 and ok.json()["image_flagged"] is False
    flagged = world["kid2"].post(f"/api/chat/conversations/{cid}/messages", data={"text": ""},
                                 files={"image": ("demo-explicit.png", buf.getvalue(), "image/png")})
    assert flagged.json()["image_flagged"] is True
    bad = world["kid2"].post(f"/api/chat/conversations/{cid}/messages", data={"text": ""},
                             files={"image": ("x.png", b"not an image", "image/png")})
    assert bad.status_code == 400
    img = world["mod1"].get(f"/api/media/{flagged.json()['id']}")
    assert img.status_code == 200 and img.headers["content-type"] == "image/jpeg"
    assert world["parent2"].get(f"/api/media/{flagged.json()['id']}").status_code == 404


def test_analyze_endpoint_needs_api_key(world):
    from app import config
    body = {"messages": [{"text": "dont tell your parents"}, {"text": "what is your number"}]}
    with TestClient(app) as raw:
        assert raw.post("/api/analyze", json=body).status_code == 401
        r = raw.post("/api/analyze", json=body, headers={"X-API-Key": config.API_KEY})
        assert r.status_code == 200 and r.json()["risk_level"] in ("Medium", "High")


def test_lockout_and_mfa(world):
    import pyotp
    p = world["parent1"]
    s = p.post("/api/auth/mfa/setup").json()
    assert s["qr"].startswith("data:image/svg")
    assert p.post("/api/auth/mfa/enable", json={"code": pyotp.TOTP(s["secret"]).now()}).status_code == 200
    from app.routers import auth as auth_router
    auth_router.limit_login.hits.clear()
    with TestClient(app, headers=H) as raw:
        assert raw.post("/api/auth/login", json={"username": "parent1", "password": PW}).json() == {"mfa_required": True}
        ok = raw.post("/api/auth/login", json={"username": "parent1", "password": PW, "totp": pyotp.TOTP(s["secret"]).now()})
        assert ok.status_code == 200
        auth_router.limit_login.hits.clear()
        for _ in range(5):
            raw.post("/api/auth/login", json={"username": "kid2", "password": "wrong-password-1"})
        assert raw.post("/api/auth/login", json={"username": "kid2", "password": PW}).status_code == 423


def test_retention_purge(world):
    from app.db import SessionLocal, Message, Alert, utcnow
    from app.services import purge_expired
    from datetime import timedelta
    with SessionLocal() as db:
        for m in db.query(Message).all():
            m.expires_at = utcnow() - timedelta(days=1)
        for a in db.query(Alert).all():
            a.expires_at = utcnow() - timedelta(days=1)
        db.commit()
        r = purge_expired(db)
        assert r["messages"] > 0 and db.query(Message).count() == 0 and db.query(Alert).count() == 0
