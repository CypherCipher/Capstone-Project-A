import os, sys, tempfile, pathlib
os.environ["SAFECON_MODELS"] = "off"        # fast + offline: use the rule-based fallbacks
os.environ["SAFECON_DATA_DIR"] = tempfile.mkdtemp(prefix="safecon_test_")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
