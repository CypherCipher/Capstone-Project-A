"use strict";
(async () => {
  const me = await requireRole("moderator");
  const main = $("#main");
  let filter = "open", current = null;

  // ---------- Alerts ----------
  const list = h("div"), detail = h("div", { class: "card" }, h("p", { class: "empty" }, "Select an alert to review it."));
  const sel = h("select", { "aria-label": "Filter alerts", onchange: () => { filter = sel.value; loadAlerts(); } },
    h("option", { value: "open" }, "Open alerts"), h("option", { value: "" }, "All alerts"),
    h("option", { value: "confirmed" }, "Confirmed"), h("option", { value: "dismissed" }, "Dismissed"), h("option", { value: "escalated" }, "Escalated"));
  const summary = h("div", { class: "row" });

  async function loadAlerts() {
    const all = await api("/api/alerts");
    const open = all.filter((a) => ["new", "reviewing"].includes(a.status));
    tabCtl.buttons.alerts.replaceChildren("Alerts", open.length ? h("span", { class: "count" }, open.length) : "");
    const shown = filter === "open" ? open : filter ? all.filter((a) => a.status === filter) : all;
    clear(summary).append(h("span", { class: "badge High" }, open.filter((a) => a.risk_level === "High").length + " high"),
      h("span", { class: "badge Medium" }, open.filter((a) => a.risk_level === "Medium").length + " medium"),
      h("span", { class: "muted small" }, "open alerts"));
    clear(list);
    if (!shown.length) list.append(h("div", { class: "card empty" }, "Nothing here. New alerts appear as children chat."));
    for (const a of shown) list.append(alertItem(a, current === a.id, () => openAlert(a)));
  }
  async function openAlert(a) {
    current = a.id;
    for (const b of list.children) b.setAttribute("aria-current", "false");
    await renderAlertDetail(detail, a, { review: true, onChange: async () => { await loadAlerts(); const fresh = await api("/api/alerts/" + a.id); openAlert(fresh); } });
  }
  const alertsEl = h("div", {}, h("div", { class: "row head" }, sel, summary), h("div", { class: "split" }, list, detail));

  // ---------- Possible violations ----------
  const vioEl = h("div");
  async function loadViolations() {
    const rows = await api("/api/mod/violations?status=pending");
    tabCtl.buttons.vio.replaceChildren("Warnings to review", rows.length ? h("span", { class: "count" }, rows.length) : "");
    const card = h("div", { class: "card" }, h("h2", {}, "Possible violations by children"),
      h("p", { class: "muted small" }, "Only content the child sent themselves appears here. Confirm a warning only after you've looked at it. Three confirmed warnings pause the child's chat for a day, and the parent is told."));
    if (!rows.length) card.append(h("p", { class: "empty" }, "Nothing waiting for review."));
    for (const v of rows) {
      const view = h("div");
      card.append(h("div", { class: "card" },
        h("div", { class: "row" }, h("b", { class: "grow" }, v.child), h("span", { class: "muted small" }, fmt(v.created_at))),
        h("p", {}, v.reason), view,
        h("div", { class: "row" },
          h("button", { class: "btn ghost small", onclick: async () => {
            const m = await api(`/api/mod/violations/${v.id}/message`);
            clear(view).append(m.expired ? h("p", { class: "muted small" }, "Message already deleted.") :
              h("div", { class: "convo" }, m.text || "", m.image_url ? imageThumb(m.image_url, m.image_flagged) : null));
          } }, "Show message"),
          h("button", { class: "btn small", onclick: () => decide(v.id, "confirm") }, "Confirm warning"),
          h("button", { class: "btn ghost small", onclick: () => decide(v.id, "dismiss") }, "Dismiss"))));
    }
    clear(vioEl).append(card);
  }
  async function decide(id, decision) {
    try { await api(`/api/mod/violations/${id}/review`, { method: "POST", json: { decision } }); toast(decision === "confirm" ? "Warning confirmed" : "Dismissed"); loadViolations(); loadKids(); }
    catch (e) { toast(e.message); }
  }

  // ---------- Children ----------
  const kidsEl = h("div");
  async function loadKids() {
    const kids = await api("/api/mod/children");
    clear(kidsEl).append(h("div", { class: "card" }, h("h2", {}, "Children at your school"),
      kids.length ? h("table", {}, h("thead", {}, h("tr", {}, ["Name", "Stars", "Warnings", "Status", ""].map((x) => h("th", {}, x)))),
        h("tbody", {}, kids.map((k) => h("tr", {}, h("td", {}, k.name), h("td", { class: "stars" }, "★ " + k.stars), h("td", {}, k.warning_count + " / 3"),
          h("td", {}, k.restricted_until ? h("span", { class: "badge High" }, "paused until " + fmt(k.restricted_until)) : h("span", { class: "badge Low" }, "active")),
          h("td", {}, k.restricted_until ? h("button", { class: "btn ghost small", onclick: async () => { await api(`/api/mod/children/${k.id}/lift`, { method: "POST" }); toast("Restriction lifted"); loadKids(); } }, "Restore chat") : "")))))
        : h("p", { class: "empty" }, "No child accounts yet. Parents create them from their dashboard.")));
  }

  // ---------- Audit ----------
  const auditEl = h("div");
  async function loadAudit() {
    const rows = await api("/api/mod/audit");
    clear(auditEl).append(h("div", { class: "card" }, h("h2", {}, "Audit log"),
      h("p", { class: "muted small" }, "Every login, alert review and view of flagged content is recorded. Message text is never written here."),
      h("table", {}, h("thead", {}, h("tr", {}, ["When", "User", "Action", "Target", "IP"].map((x) => h("th", {}, x)))),
        h("tbody", {}, rows.map((r) => h("tr", {}, h("td", {}, fmt(r.created_at)), h("td", {}, `${r.user} (${r.role})`), h("td", {}, r.action), h("td", {}, r.target), h("td", {}, r.ip || "")))))));
  }

  // ---------- System ----------
  const sysEl = h("div");
  async function loadSystem() {
    const s = await api("/api/mod/system");
    const models = Object.entries(s.models).map(([k, m]) => h("tr", {}, h("td", {}, k), h("td", {}, m.model),
      h("td", {}, h("span", { class: "badge " + (m.real ? "Low" : "Medium") }, m.real ? "real model" : m.state)), h("td", { class: "muted small" }, m.detail)));
    clear(sysEl).append(h("div", { class: "card" }, h("h2", {}, "AI models"),
      h("p", { class: "muted small" }, "If a model is not ready, SafeCon uses a clearly-labelled fallback so the app keeps working."),
      h("table", {}, h("thead", {}, h("tr", {}, ["Role", "Model", "State", "Detail"].map((x) => h("th", {}, x)))), h("tbody", {}, models))),
      h("div", { class: "card" }, h("h2", {}, "Policy"),
        h("p", {}, `Chats deleted after ${s.retention.messages_days} days. Alerts deleted after ${s.retention.alerts_days} days. ${s.warning_limit} confirmed warnings pause a child's chat for ${s.restriction_hours} hours.`),
        h("p", {}, `Open alerts: ${s.counts.alerts_open} · High: ${s.counts.high} · Medium: ${s.counts.medium} · Warnings waiting: ${s.counts.pending_violations}`)));
  }

  const tabCtl = tabs(main, {
    alerts: { label: "Alerts", el: alertsEl, load: loadAlerts },
    vio:    { label: "Warnings to review", el: vioEl, load: loadViolations },
    kids:   { label: "Children", el: kidsEl, load: loadKids },
    audit:  { label: "Audit log", el: auditEl, load: loadAudit },
    system: { label: "System", el: sysEl, load: loadSystem },
    sec:    { label: "Security", el: h("div", {}, securityPanel(me)) },
  });
  tabCtl.show("alerts");
  loadViolations();
  setInterval(() => { if (!$("#main .tab[aria-selected=true]").textContent.startsWith("Alerts")) return; loadAlerts(); }, 8000);
})();
