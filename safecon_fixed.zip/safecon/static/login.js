"use strict";
(async () => {
  try { const me = await api("/api/auth/me", { noRedirect: true }); location.href = me.home; return; } catch (_) { /* not logged in */ }
})();

const out = $("#out");
const show = (which) => {
  $("#form-in").classList.toggle("hidden", which !== "in");
  $("#form-up").classList.toggle("hidden", which !== "up");
  $("#tab-in").setAttribute("aria-selected", which === "in");
  $("#tab-up").setAttribute("aria-selected", which === "up");
  clear(out);
};
$("#tab-in").addEventListener("click", () => show("in"));
$("#tab-up").addEventListener("click", () => show("up"));

$("#form-in").addEventListener("submit", async (e) => {
  e.preventDefault();
  clear(out);
  try {
    const r = await api("/api/auth/login", { method: "POST", noRedirect: true,
      json: { username: $("#u").value.trim(), password: $("#p").value, totp: $("#t").value.trim() || null } });
    if (r.mfa_required) { $("#mfa-box").classList.remove("hidden"); $("#t").focus(); out.append(notice("info", "Enter the code from your authenticator app.")); return; }
    location.href = r.home;
  } catch (err) { out.append(notice("err", err.message)); }
});

$("#form-up").addEventListener("submit", async (e) => {
  e.preventDefault();
  clear(out);
  try {
    await api("/api/auth/register", { method: "POST", noRedirect: true, json: {
      role: $("#r").value, full_name: $("#n").value, institution: $("#i").value, username: $("#u2").value.trim(), password: $("#p2").value } });
    show("in");
    $("#u").value = $("#u2").value.trim();
    out.append(notice("ok", "Account created. Sign in to continue."));
  } catch (err) { out.append(notice("err", err.message)); }
});
