"""Integration checks for public child IDs, URL detection and safe account deletion.
The ordinary test suite uses the existing rule-based AI fallback and needs no API key.
"""
from pathlib import Path

from fastapi.testclient import TestClient

from app import config, url_safety
from app.db import Alert, Conversation, Message, SessionLocal, User, init_db
from app.main import app

H = {"X-Requested-With": "SafeCon"}
PW = "ComplexPass-2026"


def test_child_ids_migration_and_deletions(monkeypatch):
    from app.routers import auth as auth_routes
    auth_routes.limit_login.hits.clear()
    monkeypatch.setattr(config, "MOD_DELETE_KEY", "system-owner-special-key")
    with TestClient(app) as _:
        parent = TestClient(app, headers=H)
        other_parent = TestClient(app, headers=H)
        moderator = TestClient(app, headers=H)
        for cl, uname, role, inst in ((parent, "np_a", "parent", "School New"),
                                      (other_parent, "np_b", "parent", "Different New School"),
                                      (moderator, "nm_a", "moderator", "School New")):
            assert cl.post("/api/auth/register", json={"username": uname, "password": PW, "full_name": uname,
                                                     "role": role, "institution": inst}).status_code == 200
            assert cl.post("/api/auth/login", json={"username": uname, "password": PW}).status_code == 200
        k1 = parent.post("/api/parent/children", json={"username": "n_kid1", "password": PW,
                                                       "display_name": "Same Child"}).json()
        k2 = parent.post("/api/parent/children", json={"username": "n_kid2", "password": PW,
                                                       "display_name": "Same Child"}).json()
        assert k1["child_code"] != k2["child_code"]
        assert all(k["child_code"].isdigit() and len(k["child_code"]) == 5 and
                   k["child_code"][0] != "0" for k in (k1, k2))
        kid1 = TestClient(app, headers=H)
        kid2 = TestClient(app, headers=H)
        assert kid1.post("/api/auth/login", json={"username": "n_kid1", "password": PW}).status_code == 200
        assert kid2.post("/api/auth/login", json={"username": "n_kid2", "password": PW}).status_code == 200
        contacts = kid1.get("/api/chat/contacts").json()
        assert any(c["child_code"] == k2["child_code"] for c in contacts)
        cid = kid1.post("/api/chat/conversations", json={"with_user_id": k2["id"]}).json()["id"]
        assert kid1.post(f"/api/chat/conversations/{cid}/messages", data={"text": "hi"}).status_code == 200
        # Upgrade older sequential ID once; a valid 5-digit ID remains stable.
        with SessionLocal() as db:
            u = db.get(User, k2["id"])
            u.child_code = "S2"
            db.commit()
        init_db()
        with SessionLocal() as db:
            converted_code = db.get(User, k2["id"]).child_code
            assert converted_code.isdigit() and len(converted_code) == 5
            assert converted_code != k1["child_code"]
        init_db()
        with SessionLocal() as db:
            assert db.get(User, k2["id"]).child_code == converted_code
        # Other institution cannot delete someone else's child.
        assert other_parent.request("DELETE", f"/api/parent/children/{k1['id']}", json={
            "password": PW, "confirm": "DELETE"}).status_code == 404
        # Moderator delete gate is disabled with wrong owner key.
        assert moderator.request("DELETE", f"/api/mod/accounts/{k1['id']}", json={
            "password": PW, "confirm": "DELETE", "moderator_delete_key": "wrong"}).status_code == 403
        # Parents cannot delete themselves while their children exist.
        assert parent.request("DELETE", "/api/auth/me", json={
            "password": PW, "confirm": "DELETE"}).status_code == 409
        # A parent must re-enter their actual password.
        assert parent.request("DELETE", f"/api/parent/children/{k1['id']}", json={
            "password": "bad-password", "confirm": "DELETE"}).status_code == 403
        # Remove one child and its shared conversation data.
        assert parent.request("DELETE", f"/api/parent/children/{k1['id']}", json={
            "password": PW, "confirm": "DELETE"}).status_code == 200
        with SessionLocal() as db:
            assert not db.get(User, k1["id"])
            assert not db.get(Conversation, cid)
            assert not db.query(Message).filter(Message.conversation_id == cid).count()
        assert kid1.get("/api/auth/me").status_code == 401
        # Force a collision with a DELETED child's ID: must skip reserved code.
        from app import db as db_module
        deleted_id = k1["child_code"]
        available = next(str(n) for n in range(10000, 100000)
                         if str(n) not in {deleted_id, converted_code, k2["child_code"]})
        attempts = iter([int(deleted_id) - 10000, int(available) - 10000])
        with monkeypatch.context() as m:
            m.setattr(db_module.secrets, "randbelow", lambda n: next(attempts))
            k3 = parent.post("/api/parent/children", json={"username": "n_kid3", "password": PW,
                           "display_name": "Same Child"}).json()
        assert k3["child_code"] == available
        assert k3["child_code"] != deleted_id
        assert kid2.get("/api/chat/conversations").json() == []
        # Moderator can delete remaining child in their school with owner key.
        k2_id = k2["id"]
        assert moderator.request("DELETE", f"/api/mod/accounts/{k2_id}", json={
            "password": PW, "confirm": "DELETE", "moderator_delete_key": "system-owner-special-key"}).status_code == 200
        assert kid2.get("/api/auth/me").status_code == 401
        # Self delete parent when no children remain.
        assert parent.request("DELETE", f"/api/parent/children/{k3['id']}", json={
            "password": PW, "confirm": "DELETE"}).status_code == 200
        assert parent.request("DELETE", "/api/auth/me", json={
            "password": PW, "confirm": "DELETE"}).status_code == 200
        assert parent.get("/api/auth/me").status_code == 401
        assert parent.post("/api/auth/login", json={"username": "np_a", "password": PW}).status_code == 401


def test_safe_browsing_lookup_only_calls_google_and_does_not_expose_tokens(monkeypatch):
    monkeypatch.setattr(config, "SAFE_BROWSING_KEY", "test-key")
    url_safety._CACHE.clear()
    calls = []
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {"threats": [{"url": "https://evil.example/login", "threatTypes": ["SOCIAL_ENGINEERING"]}],
                    "cacheDuration": "600s"}
    def fake_get(url, **kwargs):
        calls.append((url, kwargs))
        return Response()
    monkeypatch.setattr(url_safety.httpx, "get", fake_get)
    result = url_safety.scan("Check https://evil.example/login?password=super-secret#private")
    assert result[0]["verdict"] == "malicious"
    assert result[0]["threat_types"] == ["SOCIAL_ENGINEERING"]
    assert "password" not in str(result)
    assert len(calls) == 1 and calls[0][0] == url_safety.LOOKUP_ENDPOINT
    assert calls[0][1]["params"]["urls"] == "https://evil.example/login"
    assert len(url_safety._CACHE) == 1
    # Cached response should avoid further API calls.
    url_safety.scan("https://evil.example/login?key=another-secret")
    assert len(calls) == 1
    url_safety.scan("http://127.0.0.1/admin")
    assert len(calls) == 1  # private destinations never submitted to Google


def test_no_api_does_not_claim_safe(monkeypatch):
    monkeypatch.setattr(config, "SAFE_BROWSING_KEY", "")
    scans = url_safety.scan("https://example.org")
    assert scans[0]["verdict"] == "unverified"
    assert "https://example.org" not in str(scans)
    assert url_safety.extract("help at me@example.org") == []
    assert url_safety.extract("check example.org please") == ["example.org"]


def test_url_scan_in_chat_and_alerts(monkeypatch):
    from app.routers import auth as auth_routes
    auth_routes.limit_login.hits.clear()
    monkeypatch.setattr(config, "SAFE_BROWSING_KEY", "demo-key")
    url_safety._CACHE.clear()
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {"threats": [{"url": "https://test-phish.example/x", "threatTypes": ["SOCIAL_ENGINEERING"]}],
                    "cacheDuration": "120s"}
    monkeypatch.setattr(url_safety.httpx, "get", lambda *args, **kwargs: Response())
    with TestClient(app) as _:
        par = TestClient(app, headers=H)
        mod = TestClient(app, headers=H)
        for c, username, role in ((par, "url_parent", "parent"), (mod, "url_mod", "moderator")):
            assert c.post("/api/auth/register", json={"username": username, "password": PW,
                "full_name": username, "role": role, "institution": "URL Demo School"}).status_code == 200
            assert c.post("/api/auth/login", json={"username": username, "password": PW}).status_code == 200
        c1 = par.post("/api/parent/children", json={"username": "url_c1", "display_name": "A", "password": PW})
        # Display name must have >= 2 chars.
        assert c1.status_code == 422
        c1 = par.post("/api/parent/children", json={"username": "url_c1", "display_name": "Ada", "password": PW}).json()
        c2 = par.post("/api/parent/children", json={"username": "url_c2", "display_name": "Ben", "password": PW}).json()
        kid = TestClient(app, headers=H)
        assert kid.post("/api/auth/login", json={"username": "url_c1", "password": PW}).status_code == 200
        cid = kid.post("/api/chat/conversations", json={"with_user_id": c2["id"]}).json()["id"]
        r = kid.post(f"/api/chat/conversations/{cid}/messages", data={
            "text": "See https://test-phish.example/x?session=private-secret"})
        assert r.status_code == 200
        msg = r.json()
        assert msg["url_scans"][0]["verdict"] == "malicious"
        assert "private-secret" not in str(msg)
        assert "[link hidden]" in msg["text"]
        visible = kid.get(f"/api/chat/conversations/{cid}/messages").json()["messages"]
        assert visible[-1]["url_scans"][0]["threat_types"] == ["SOCIAL_ENGINEERING"]
        a = mod.get("/api/alerts").json()
        assert a and a[0]["risk_level"] == "High"
        assert any("malicious" in s.lower() for s in a[0]["indicators"])
        details = mod.get(f"/api/alerts/{a[0]['id']}/messages").json()["messages"]
        assert details[-1]["url_scans"][0]["verdict"] == "malicious"
        # A URL alone must not earn the sender a confirmed-or-pending warning.
        assert not mod.get("/api/mod/violations").json()
