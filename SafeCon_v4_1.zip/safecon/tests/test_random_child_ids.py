"""Random five-digit public ID invariants; no actual AI models are needed."""
from app.db import ChildIDReservation, SessionLocal, User, init_db, new_child_code


def test_random_id_format_and_unique_allocation():
    init_db()
    with SessionLocal() as db:
        codes = [new_child_code(db) for _ in range(30)]
        assert len(set(codes)) == len(codes)
        assert all(len(code) == 5 and code.isascii() and code.isdigit() and
                   10000 <= int(code) <= 99999 for code in codes)
        db.commit()
    with SessionLocal() as db:
        assert all(db.get(ChildIDReservation, code) is not None for code in codes)


def test_legacy_id_upgrade_and_stability():
    init_db()
    with SessionLocal() as db:
        # Existing already-valid five-digit child ID should remain unchanged
        existing = db.query(User).filter(User.role == "child").first()
        if existing is None:
            return
        original = existing.child_code
    init_db()
    with SessionLocal() as db:
        assert db.get(User, existing.id).child_code == original
