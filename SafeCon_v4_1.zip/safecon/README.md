# SafeCon prototype

A working prototype of the SafeCon capstone proposal (Online Grooming Detection): a chat for children inside an institution,
with parent and moderator dashboards. FastAPI + a plain HTML/JS front end (no build step).

## 1. Run it

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm

python seed.py                       # demo accounts + a demo conversation (add --fast to skip loading AI models)
python -m uvicorn app.main:app --port 8000
```

Open http://localhost:8000. All demo accounts use the password `SafeCon-Demo-2026`:

| Username      | Role      | Notes                                   |
|---------------|-----------|-----------------------------------------|
| `mod_demo`    | moderator | sees all alerts at "Demo School"        |
| `parent_demo` | parent    | parent of Sara and Omar                 |
| `parent_two`  | parent    | parent of Rami                          |
| `sara`, `omar`, `rami` | child | chat with each other                 |

The first start downloads the three Hugging Face models (about 700 MB total) in the background. The **System** tab on the
moderator dashboard shows whether each one loaded ("real model") or is using a fallback.

## 2. Demo script (5 minutes)

1. Log in as `mod_demo`: the seeded conversation already produced a High alert (secrecy + personal info), a SHAP word list,
   and a pending warning for Sara (she shared a phone number, which was masked before storing).
2. Open the alert, read the flagged conversation, press **Confirm risk**. Check the audit log tab.
3. Log in as `parent_demo` (another browser or a private window): see the alert, Sara's stars, interests, warning history, notifications.
4. Log in as `sara` and `rami` in two windows and chat. Try: "how old are you?" (no alert), then "don't tell your parents, our secret",
   then "what's your number" (alert appears). Try "thank you so much for helping me" (star; repeating it won't give another).
5. As the moderator, confirm 3 warnings for one child: their chat pauses and the parent gets a notification. Use **Restore chat** to lift it.
6. Turn on MFA from the Security tab (any authenticator app), log out, and log in again.

## 3. What is in it (proposal -> code)

| Proposal item | Where |
|---|---|
| FastAPI REST API, 3 layers (front end -> logic -> DB) | `app/main.py`, `app/routers/`, `app/services.py`, `app/db.py`, `static/` |
| Slang, emoji, spelling normalization (regex, spaCy, slang dict, emoji lib) | `app/nlp/normalize.py` |
| Conversation windows, DistilBERT grooming classifier | `app/services.py`, `app/nlp/models.py` (`erikaecl/hansen-grooming-distilbert`) |
| Sensitive-data detection (regex + spaCy NER) and masking | `app/nlp/sensitive.py` |
| ViT image check (Falconsai/nsfw_image_detection) | `app/nlp/models.py`, `app/services.py` |
| Risk rules High/Medium/Low | `app/nlp/risk.py` |
| SHAP explanations | `app/nlp/explain.py` |
| Warning system (moderator-confirmed, temporary restriction, parent notified) | `app/services.py`, `app/routers/mod.py` |
| Interests analyzer (all-MiniLM-L6-v2 + cosine) | `app/nlp/interests.py` |
| Star rewards with duplicate/cooldown checks | `app/nlp/stars.py` |
| Argon2, short-lived JWT, MFA (TOTP), lockout, rate limits, API key | `app/security.py`, `app/routers/auth.py`, `app/routers/analyze.py` |
| AES-256-GCM encrypted chat + images, 30-day / 90-day deletion | `app/security.py`, `app/services.py` (`purge_expired`, runs hourly) |
| Role-based access on every request, audit logs | `app/deps.py`, `app/routers/*.py` |
| XSS defences (textContent only, CSP, HttpOnly SameSite cookie), CSRF header | `static/app.js`, `app/main.py` |
| Security-event log for Wazuh | `data/security.log` (JSON lines, no message text) |

## 4. Decisions you should know about

- **No training.** The text model is the public `erikaecl/hansen-grooming-distilbert` (the baseline in your proposal) instead of your own PAN12 fine-tune.
  The code reads the model's label names to find the "grooming" label. If the moderator **System** tab shows the wrong label,
  set `SAFECON_TEXT_GROOMING_LABEL` (e.g. `LABEL_1`). To use your own model later, set `SAFECON_TEXT_MODEL` to its folder or Hub id.
- **Fallbacks.** If a model can't load, a rule-based stand-in keeps the app working and is labelled "fallback-rules" on every alert.
  For images the fallback is a demo stub: a file named `demo-explicit.jpg` is treated as explicit so you can test that path without the model.
- **"Personal information"** in the risk rules means shared *or* requested. A single "how old are you?" is deliberately not a request.
  Names and places only count when the child is talking about themselves ("my name is...", "I live in...").
- **Masking:** phone numbers, emails, links, usernames and addresses are replaced by `[phone hidden]` etc. *before* the message is stored.
- **Alerts hold no message text.** Moderators and parents read flagged messages from the encrypted chat store (every view is audit-logged), and flagged images are blurred until clicked.
- **Moderators** see all children of their school/centre (matched by the institution name typed at sign-up). Parents see only their own children's alerts.
- Chat is children chatting with other children at the same institution (polling every 2.5 s, no websockets).

## 5. Prototype shortcuts (what to say in your report)

SQLite instead of PostgreSQL, in-memory rate limiter, MFA optional (not forced), keys auto-generated in `data/.secrets/`
(set `SAFECON_DATA_KEY`, `SAFECON_JWT_SECRET`, `SAFECON_API_KEY` in production), no password reset or email, and no backup job.

**TLS 1.3 only** is done at a reverse proxy, e.g. nginx: `ssl_protocols TLSv1.3;` then run with `SAFECON_COOKIE_SECURE=1`.

## 6. Tests and security checks

```bash
python -m pytest -q tests                 # 13 tests: auth, lockout, MFA, roles, masking, risk rules, alerts, stars, images, retention
bandit -r app                             # static analysis
pip-audit -r requirements.txt             # vulnerable packages
# OWASP ZAP: point a baseline scan at http://localhost:8000
```
Tests run with `SAFECON_MODELS=off`, so they use the fallbacks and need no downloads.

`/api/docs` has the interactive API docs. The service key for `/api/analyze` is in `data/.secrets/api_key`.

## 7. New features — child IDs, URL safety checks, account removal

### Child IDs (automatic, including existing accounts)

Each child receives a randomly generated **five-digit public ID** such as `58321` or
`19482`. IDs are generated with Python's cryptographically secure `secrets` library,
checked against existing records, and stored in a permanent reservation ledger so they
**will never be reused even after an account is deleted**. They are not derived from
names, ages, schools, or other personal attributes. These IDs are **not passwords** or
proof of identity; all access remains subject to authentication and authorization.

IDs are shown in the Parent dashboard, Moderator > Children, and the child chat
contact picker and conversation title. Children can be searched by name or child ID.

**Existing databases are preserved:** On application startup `app/db.py` performs an
additive SQLite upgrade and converts legacy `S1`, `S2`, `SC-XXXX-XXXX`, or missing IDs
to unique five-digit IDs **once**. Any already-valid five-digit ID is retained on
future restarts. The new `child_id_reservations` table preserves prior assignments;
the obsolete `child_code_sequence` table (if present) is left untouched for safety.
**Back up your entire `data` folder before upgrading.** The old public ID values will
change during the one-time migration; the database's internal `users.id` identifiers
and account relationships do not change. No re-seeding or account recreation needed.

Five digits provide a maximum of 90,000 possible IDs; this scheme is intended for the
prototype. A larger deployment should use a longer identifier and migration tooling.

### Link/URL safety checks

- SafeCon finds `https://`, `http://`, `www.` and ordinary bare domains in chat,
  masks the actual link before saving the message, and records **sanitized** results.
- The local URL inspection checks hostname, IP vs domain, HTTPS, punycode, unusual
  subdomains, shorteners, URL structure, and common phishing-like wording. These are
  **heuristics**, not trained AI, not definitive fraud detection.
- If configured, Google Safe Browsing **v5** checks submitted host+path against known
  phishing/social-engineering, malware and other dangerous URLs. This sends the URL
  scheme, hostname, port and path to Google; the query string, fragment and embedded
  credentials are omitted to reduce disclosure. **Do not use URLs with private
  tokens in the path.** Local/non-public network hosts aren't sent to Google.
- The app **never opens, crawls, downloads, or executes content from the user-sent
  site**. It does not fetch a page title, HTML, JavaScript, or Open Graph metadata;
  those activities would need separate SSRF-safe sandboxed infrastructure.
- Results appear beneath messages and in flagged-conversation views as:
  `Known harmful URL`, `Suspicious URL`, `No known threat found`, or `URL not verified`.
  A **confirmed** Google threat triggers a High-risk alert; suspicious URL structure
  produces a moderator-visible risk signal. Neither a clean lookup nor absence of
  local indicators guarantees a URL is safe.
- Sending a URL by itself no longer creates a *pending disciplinary warning* for a
  child, although it may create a safety **alert**. Warnings still require moderator
  confirmation for other violations.

**Enable live Google Safe Browsing on Windows PowerShell before launching the server:**

```powershell
$env:SAFECON_SAFE_BROWSING_KEY = "YOUR_GOOGLE_SAFE_BROWSING_API_KEY"
python -m uvicorn app.main:app --port 8000
```

The API key is obtained through a Google Cloud project with the Safe Browsing API
(v5) enabled. The API is intended for **non-commercial** use; for commercial use,
consider Google's Web Risk product instead. The app uses the Google Safe Browsing
`GET /v5/urls:search` API with a limited response cache; it doesn't use a VirusTotal
submission or download suspicious webpages. **With no key or during an API outage,
SafeCon returns `unverified`, NOT `safe`.** This prototype has not been tested with
live production API credentials; tests mock the Google service.

### Account deletion

- **All users:** top bar > **Delete my account**. Re-enter your own password,
  provide MFA code when enabled, and type `DELETE`.
- **Parents:** My children > **Remove child account**. Parents can delete only their
  own children's accounts and must re-enter their own credentials.
- **Moderators:** Manage accounts > **Delete account**. They can remove child or
  parent accounts from **their own institution only**. Deletion of *other* moderators
  is intentionally unsupported. They need their own password/MFA plus an additional
  **owner-managed moderator deletion key**, which is disabled by default.
- A parent with linked children cannot be deleted until the children are removed
  (to prevent orphaned accounts).
- Deleting a child removes **both participants' shared conversations**, associated
  messages, uploaded pictures, alerts, violations and stars, along with the child's
  own profile. The other child will lose those chat threads too. This is permanent.
- The database deletion and related file cleanup are implemented for this academic
  prototype. Operational log files may still contain historical numeric IDs/event
  metadata; full production privacy compliance, legal retention, recovery, and audit
  requirements need additional review. Always back up the database before testing
  destructive actions.

**Enable moderator deletion in PowerShell using a long secret known to the owner:**

```powershell
$env:SAFECON_MOD_DELETE_KEY = "REPLACE_WITH_A_LONG_PRIVATE_RANDOM_SECRET"
python -m uvicorn app.main:app --port 8000
```

Enter that owner key only when confirming a moderator deletion. The key is **not**
stored in the interface. Without the environment variable, moderator deletion
returns a 403 (by design). Self-deletion and parent-controlled child deletion do
not need this key.

**Important:** This prototype currently allows self-registration as a moderator
using an institution name. That does not verify a real school administrator. Before
any real deployment, institute verified staff onboarding and stronger organizational
access controls. Never deploy a child-safety service handling real children without
reviewing privacy, safeguarding, authorization, monitoring, retention and recovery.

### Testing the new features

Run the complete test suite with the dependencies from `requirements.txt`:

```powershell
python -m pytest -q tests
```

The codebase now includes **17 tests**. The added tests cover stable child-ID
assignment and migration, deleted-user session invalidation, role-scoped deletion,
password and owner-key checks, shared-conversation cleanup, Safe Browsing request
sanitization/caching, and URL scan integration with chat alerts. The Google calls
are **mocked in tests**; live Google API success still needs verification with your key.
