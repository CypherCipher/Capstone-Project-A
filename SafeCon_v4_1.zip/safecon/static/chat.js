"use strict";
let me, convId = null, lastId = 0, timer = null;

(async () => {
  me = await requireRole("child");
  showStars(me.stars);
  await loadContacts();
  $("#composer").addEventListener("submit", send);
  $("#file").addEventListener("change", () => { $("#file-name").textContent = $("#file").files[0] ? "Picture ready: " + $("#file").files[0].name : ""; });
})();

function showStars(n) { $("#stars").textContent = "★ " + n + (n === 1 ? " star" : " stars"); }

async function loadContacts() {
  const [contacts, convs] = await Promise.all([api("/api/chat/contacts"), api("/api/chat/conversations")]);
  const box = clear($("#contacts"));
  if (!contacts.length) box.append(h("p", { class: "muted" }, "No one else from your school has an account yet."));
  const search = h("input", { type: "search", placeholder: "Search name or child ID", "aria-label": "Search children" });
  box.append(search);
  const buttons = [];
  search.addEventListener("input", () => {
    const q = search.value.toLowerCase().trim();
    for (const b of buttons) b.classList.toggle("hidden", !b.dataset.search.includes(q));
  });
  for (const c of contacts) {
    const b = h("button", { class: "pick", onclick: () => openChat(c) },
      h("b", {}, c.name), h("span", { class: "child-id" }, c.child_code || ""));
    b.dataset.search = (c.name + " " + (c.child_code || "")).toLowerCase();
    buttons.push(b);
    b.dataset.id = c.id;
    box.append(b);
  }
}

async function openChat(contact) {
  const c = await api("/api/chat/conversations", { method: "POST", json: { with_user_id: contact.id } });
  convId = c.id; lastId = 0;
  clear($("#log"));
  $("#title").textContent = "Chat with " + c.name + " (" + c.child_code + ")";
  document.querySelectorAll(".pick").forEach((b) => b.setAttribute("aria-current", b.dataset.id == contact.id));
  clearInterval(timer);
  await poll();
  timer = setInterval(poll, 2500);
  $("#text").focus();
}

async function poll() {
  if (!convId) return;
  try {
    const r = await api(`/api/chat/conversations/${convId}/messages?after=${lastId}`);
    const banner = clear($("#banner"));
    if (r.restricted) banner.append(notice("info", "Your chat is paused for now. A moderator or your parent can switch it back on."));
    const log = $("#log");
    const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;
    for (const m of r.messages) {
      lastId = Math.max(lastId, m.id);
      log.append(h("div", { class: "bub" + (m.mine ? " mine" : "") },
        // Children see only the protected message; scan verdicts are for parents/moderators.
        m.text || null, m.image_url ? imageThumb(m.image_url, m.image_flagged) : null,
        h("span", { class: "t" }, fmtTime(m.created_at))));
    }
    if (r.messages.length && (atBottom || r.messages[r.messages.length - 1].mine)) log.scrollTop = log.scrollHeight;
  } catch (e) { /* network hiccup: try again on the next tick */ }
}

async function send(e) {
  e.preventDefault();
  if (!convId) return toast("Pick a friend first.");
  const text = $("#text").value.trim(), file = $("#file").files[0];
  if (!text && !file) return;
  const form = new FormData();
  form.append("text", text);
  if (file) form.append("image", file);
  const btn = $("#composer button"); btn.disabled = true;
  try {
    const r = await api(`/api/chat/conversations/${convId}/messages`, { method: "POST", form });
    $("#text").value = ""; $("#file").value = ""; $("#file-name").textContent = "";
    if (r.masked && r.masked.length) toast("We hid some personal details to keep you safe. Please don't share them in chat.", 5000);
    if ((r.url_scans || []).some(s => s.verdict === "malicious")) toast("Known malicious link detected, masked and flagged for review.", 6000);
    if (r.star) { me.stars += 1; showStars(me.stars); toast("★ You earned a star for being kind!"); }
    await poll();
  } catch (err) { toast(err.message, 5000); }
  finally { btn.disabled = false; $("#text").focus(); }
}
