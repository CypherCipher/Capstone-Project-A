"use strict";
(async () => {
  const me = await requireRole("parent");
  const main = $("#main");

  // ---------- Children ----------
  const kidsEl = h("div");
  const addForm = h("form", { class: "card", onsubmit: async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    try {
      await api("/api/parent/children", { method: "POST", json: { display_name: f.get("name"), username: f.get("username"), password: f.get("password") } });
      e.target.reset(); toast("Child account created"); loadKids();
    } catch (err) { toast(err.message, 5000); }
  } },
    h("h2", {}, "Add a child account"),
    h("p", { class: "muted small" }, "Your child signs in at the same page with this username and password."),
    h("label", { for: "cn" }, "Child's display name"), h("input", { id: "cn", name: "name", type: "text", required: true, minLength: 2, maxLength: 60 }),
    h("label", { for: "cu" }, "Username"), h("input", { id: "cu", name: "username", type: "text", required: true, minLength: 3, maxLength: 32 }),
    h("label", { for: "cp" }, "Password (10+ characters)"), h("input", { id: "cp", name: "password", type: "password", required: true, minLength: 10, autocomplete: "new-password" }),
    h("p"), h("button", { class: "btn", type: "submit" }, "Create account"));

  async function loadKids() {
    const kids = await api("/api/parent/children");
    const grid = h("div", { class: "grid" });
    if (!kids.length) grid.append(h("div", { class: "card empty" }, "No child accounts yet. Add one below."));
    for (const k of kids) {
      const confirmed = k.warnings.filter((w) => w.status === "confirmed");
      grid.append(h("div", { class: "card" },
        h("div", { class: "row" }, h("h2", { class: "grow nomargin" }, k.name), h("span", { class: "stars" }, "★ " + k.stars)),
        h("p", { class: "muted small" }, "Child ID: " + k.child_code + " · Username: " + k.username),
        k.restricted_until ? notice("err", "Chat paused until " + fmt(k.restricted_until)) : null,
        h("p", {}, h("b", {}, "Warnings: "), `${k.warning_count} of 3 before a temporary pause`),
        h("h3", {}, "Interests"),
        k.interests.length ? h("div", { class: "chips" }, k.interests.map((i) => h("span", { class: "chip" }, i.category))) : h("p", { class: "muted small" }, "Nothing noticeable yet."),
        h("h3", {}, "Warning history"),
        k.warnings.length ? h("table", {}, h("tbody", {}, k.warnings.map((w) =>
          h("tr", {}, h("td", {}, fmt(w.created_at)), h("td", {}, w.reason), h("td", {}, h("span", { class: "badge st" }, w.status === "pending" ? "awaiting review" : w.status))))))
          : h("p", { class: "muted small" }, "No warnings."),
        h("button", { class: "btn danger small", onclick: () => accountDeletionDialog({
          title: "Delete child account: " + k.name + " (" + k.child_code + ")",
          endpoint: `/api/parent/children/${k.id}`,
          description: "You must confirm with YOUR parent password. This deletes the child account and shared conversations, including the other child's history.",
          onSuccess: () => { loadKids(); loadAlerts(); }
        }) }, "Remove child account")));
    }
    clear(kidsEl).append(grid, h("p"), addForm);
  }

  // ---------- Alerts ----------
  const list = h("div"), detail = h("div", { class: "card" }, h("p", { class: "empty" }, "Select an alert to see why it was flagged."));
  let current = null;
  async function loadAlerts() {
    const alerts = await api("/api/alerts");
    const open = alerts.filter((a) => ["new", "reviewing"].includes(a.status)).length;
    tabCtl.buttons.alerts.replaceChildren("Alerts", open ? h("span", { class: "count" }, open) : "");
    clear(list);
    if (!alerts.length) list.append(h("div", { class: "card empty" }, "No alerts. Nothing worrying has been spotted in your children's chats."));
    for (const a of alerts) list.append(alertItem(a, current === a.id, async () => {
      current = a.id; loadAlerts(); await renderAlertDetail(detail, a);
    }));
  }
  const alertsEl = h("div", { class: "split" }, list, detail);

  // ---------- Notifications ----------
  const notesEl = h("div");
  async function loadNotes() {
    const ns = await api("/api/parent/notifications");
    clear(notesEl).append(h("div", { class: "card" },
      h("div", { class: "row" }, h("h2", { class: "grow nomargin" }, "Notifications"),
        h("button", { class: "btn ghost small", onclick: async () => { await api("/api/parent/notifications/read", { method: "POST" }); loadNotes(); } }, "Mark all read")),
      ns.length ? h("table", {}, h("tbody", {}, ns.map((n) => h("tr", {}, h("td", {}, n.read ? "" : "●"), h("td", {}, n.text), h("td", { class: "muted small" }, fmt(n.created_at))))))
        : h("p", { class: "muted" }, "You're all caught up.")));
    const unread = ns.filter((n) => !n.read).length;
    tabCtl.buttons.notes.replaceChildren("Notifications", unread ? h("span", { class: "count" }, unread) : "");
  }

  const tabCtl = tabs(main, {
    kids:   { label: "My children", el: kidsEl, load: loadKids },
    alerts: { label: "Alerts", el: alertsEl, load: loadAlerts },
    notes:  { label: "Notifications", el: notesEl, load: loadNotes },
    sec:    { label: "Security", el: h("div", {}, securityPanel(me)) },
  });
  tabCtl.show("kids");
  loadAlerts(); loadNotes();
})();
