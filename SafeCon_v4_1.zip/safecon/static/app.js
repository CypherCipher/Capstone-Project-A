"use strict";
/* Shared helpers. Everything user-supplied is inserted with textContent (never innerHTML) -> no XSS. */
const $ = (sel, root = document) => root.querySelector(sel);

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (k === "for") el.setAttribute("for", v);
    else if (k in el) el[k] = v;
    else el.setAttribute(k, v);
  }
  for (const c of kids.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}
const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

async function api(path, opts = {}) {
  const init = { method: opts.method || "GET", headers: { "X-Requested-With": "SafeCon" }, credentials: "same-origin" };
  if (opts.json !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(opts.json); }
  if (opts.form) init.body = opts.form;
  const res = await fetch(path, init);
  if (res.status === 401 && !opts.noRedirect) { location.href = "/index.html"; throw new Error("Please log in."); }
  let data = null;
  try { data = await res.json(); } catch (_) { /* no body */ }
  if (!res.ok) {
    const d = data && data.detail;
    throw new Error(typeof d === "string" ? d : (Array.isArray(d) && d[0] && d[0].msg) || "Something went wrong.");
  }
  return data;
}

const utc = (iso) => new Date(/Z|[+-]\d\d:\d\d$/.test(iso) ? iso : iso + "Z");
const fmt = (iso) => utc(iso).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
const fmtTime = (iso) => utc(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const pct = (x) => Math.round((x || 0) * 100) + "%";

function toast(text, ms = 3500) {
  const t = h("div", { class: "toast", role: "status" }, text);
  document.body.append(t);
  setTimeout(() => t.remove(), ms);
}
function notice(kind, text) { return h("div", { class: "msg " + kind, role: kind === "err" ? "alert" : "status" }, text); }

async function requireRole(role) {
  const me = await api("/api/auth/me");
  if (me.role !== role) { location.href = me.home; throw new Error("redirect"); }
  const bar = $("#topbar");
  clear(bar).append(
    h("span", { class: "brand" }, "SafeCon"),
    h("span", { class: "who" }, `${me.full_name}${me.child_code ? " · " + me.child_code : ""} · ${me.institution || ""}`),
    h("button", { onclick: () => accountDeletionDialog({ title: "Delete my account", endpoint: "/api/auth/me",
      description: "Permanently deletes your account and related records. Child account deletion also removes shared conversations for the other participants. Parents must remove their child accounts first.",
      onSuccess: () => { location.href = "/index.html"; } }) }, "Delete my account"),
    h("button", { onclick: async () => { await api("/api/auth/logout", { method: "POST", noRedirect: true }); location.href = "/index.html"; } }, "Log out"));
  return me;
}

function tabs(container, panels, onSwitch) {
  const bar = h("div", { class: "tabs", role: "tablist" });
  const buttons = {};
  const show = (key) => {
    for (const [k, b] of Object.entries(buttons)) { b.setAttribute("aria-selected", k === key); panels[k].el.classList.toggle("hidden", k !== key); }
    if (panels[key].load) panels[key].load();
    if (onSwitch) onSwitch(key);
  };
  for (const [k, p] of Object.entries(panels)) {
    buttons[k] = h("button", { class: "tab", role: "tab", onclick: () => show(k) }, p.label);
    bar.append(buttons[k]);
    p.el.classList.add("hidden");
  }
  container.append(bar, ...Object.values(panels).map((p) => p.el));
  return { show, buttons };
}

const badge = (level) => h("span", { class: "badge " + level }, level);
const meter = (value, level) => h("div", { class: "meter " + (level || "") }, (() => { const s = h("span"); s.style.width = pct(value); return s; })());

function imageThumb(url, flagged) {
  const img = h("img", { class: "thumb" + (flagged ? " blur" : ""), src: url, alt: flagged ? "Flagged image (blurred). Click to reveal." : "Shared picture" });
  if (flagged) img.addEventListener("click", () => img.classList.toggle("blur"));
  return img;
}

/* Alert detail used by both the parent and the moderator dashboards. */
async function renderAlertDetail(box, alert, opts = {}) {
  clear(box).append(h("p", { class: "muted" }, "Loading…"));
  const msgs = await api(`/api/alerts/${alert.id}/messages`);
  clear(box);
  box.append(
    h("div", { class: "row" }, h("h2", {}, "Alert #" + alert.id), badge(alert.risk_level),
      h("span", { class: "badge st" }, alert.status), h("span", { class: "grow" }),
      h("span", { class: "muted small" }, fmt(alert.updated_at))),
    h("p", { class: "muted" }, `Conversation between ${alert.participants.join(" and ")}. Latest flagged message from ${alert.trigger}.`),
    notice("info", "An alert shows a possible risk. It is a warning sign, not proof that grooming has happened."),
    h("h3", {}, "Why it was flagged"),
    h("div", { class: "chips" }, alert.indicators.map((i) => h("span", { class: "chip hot" }, i))),
    h("div", {}, h("span", { class: "small" }, `Text model confidence ${pct(alert.text_conf)}`), meter(alert.text_conf, alert.risk_level)),
    // Native Element.append(null) literally writes "null" to the page; only pass actual nodes.
    ...(alert.image_conf !== null && alert.image_conf !== undefined
      ? [h("div", {}, h("span", { class: "small" }, `Image model: explicit confidence ${pct(alert.image_conf)}`), meter(alert.image_conf, alert.risk_level))]
      : []),
    ...(Array.isArray(alert.explanation) && alert.explanation.length
      ? [h("div", {},
          h("h3", {}, "Words that raised the score (SHAP)"),
          h("div", { class: "chips" }, alert.explanation.map((e) => h("span", { class: "chip" }, `${e.token}  +${e.weight}`))))]
      : []),
    h("p", { class: "muted small" }, "Model: " + (alert.model_source || "unknown")),
    h("h3", {}, "Flagged conversation"));
  if (msgs.expired) {
    box.append(h("p", { class: "muted" }, "The chat messages have been deleted after the 30-day retention period. Only this alert record remains."));
  } else {
    const log = h("div", { class: "convo" });
    for (const m of msgs.messages) {
      log.append(h("div", { class: "m" + (m.is_trigger ? " trigger" : "") }, h("b", {}, m.sender + ": "), m.text || "",
        m.image_url ? imageThumb(m.image_url, m.image_flagged) : null, urlScanBadges(m.url_scans)));
    }
    box.append(log);
  }
  if (opts.review) {
    const note = h("textarea", { maxLength: 200, placeholder: "Optional note for the record (don't paste message text)", value: alert.note || "" });
    const set = async (status) => {
      try { await api(`/api/alerts/${alert.id}`, { method: "PATCH", json: { status, note: note.value } }); toast("Marked as " + status); opts.onChange && opts.onChange(); }
      catch (e) { toast(e.message); }
    };
    box.append(h("h3", {}, "Your review"), note,
      h("div", { class: "row" },
        h("button", { class: "btn ghost small", onclick: () => set("reviewing") }, "Start reviewing"),
        h("button", { class: "btn small", onclick: () => set("confirmed") }, "Confirm risk"),
        h("button", { class: "btn ghost small", onclick: () => set("dismissed") }, "Dismiss as false alarm"),
        h("button", { class: "btn danger small", onclick: () => set("escalated") }, "Escalate")));
  } else if (alert.note) {
    box.append(h("p", {}, h("b", {}, "Moderator note: "), alert.note));
  }
}

function alertItem(a, current, onclick) {
  const done = !["new", "reviewing"].includes(a.status);
  return h("button", { class: `item ${a.risk_level}${done ? " done" : ""}`, "aria-current": current, onclick },
    h("div", { class: "row" }, badge(a.risk_level), h("span", { class: "badge st" }, a.status), h("span", { class: "grow" }),
      h("span", { class: "muted small" }, fmt(a.updated_at))),
    h("div", {}, a.participants.join(" & ")),
    h("div", { class: "muted small" }, a.indicators.join(" · ") || "—"));
}

/* Two-factor (TOTP) panel shared by parent and moderator pages */
function securityPanel(me) {
  const box = h("div", { class: "card" });
  const draw = (user) => {
    clear(box).append(h("h2", {}, "Two-factor login (MFA)"));
    if (user.mfa_enabled) {
      const code = h("input", { type: "text", inputMode: "numeric", placeholder: "6-digit code", autocomplete: "one-time-code" });
      box.append(h("p", {}, "MFA is on. You will be asked for a code from your authenticator app when you log in."),
        h("label", { for: "dis" }, "Enter a current code to turn it off"), (code.id = "dis", code),
        h("button", { class: "btn danger small", onclick: async () => {
          try { await api("/api/auth/mfa/disable", { method: "POST", json: { code: code.value } }); draw(await api("/api/auth/me")); } catch (e) { toast(e.message); }
        } }, "Turn off MFA"));
    } else {
      box.append(h("p", {}, "Add a second step to your login with an authenticator app (Google Authenticator, Authy, 1Password…)."),
        h("button", { class: "btn", onclick: async () => {
          const s = await api("/api/auth/mfa/setup", { method: "POST" });
          const code = h("input", { type: "text", inputMode: "numeric", placeholder: "6-digit code", autocomplete: "one-time-code", id: "en" });
          clear(box).append(h("h2", {}, "Scan this code"), h("img", { class: "qr", src: s.qr, alt: "MFA QR code" }),
            h("p", { class: "small muted" }, "Can't scan? Enter this key by hand: " + s.secret),
            h("label", { for: "en" }, "Then type the 6-digit code to finish"), code,
            h("button", { class: "btn", onclick: async () => {
              try { await api("/api/auth/mfa/enable", { method: "POST", json: { code: code.value } }); toast("MFA is on"); draw(await api("/api/auth/me")); } catch (e) { toast(e.message); }
            } }, "Turn on MFA"));
        } }, "Set up MFA"));
    }
  };
  draw(me);
  return box;
}


/* UI never displays an actual clickable URL, only the sanitized hostname and result. */
function urlScanBadges(scans = []) {
  if (!scans || !scans.length) return null;
  return h("div", { class: "url-results" }, scans.map((s) => {
    const labels = { malicious: "Known harmful URL", suspicious: "Suspicious URL — review",
      no_known_threats: "No known threat found (not guaranteed safe)", unverified: "URL not verified" };
    const kind = s.verdict === "malicious" ? "High" : s.verdict === "suspicious" ? "Medium" : "st";
    return h("div", {}, h("span", { class: "badge " + kind }, labels[s.verdict] || "URL checked"),
      h("span", { class: "muted small" }, "  " + s.host + " · " + (s.provider || "not checked")),
      s.threat_types && s.threat_types.length ? h("p", { class: "small" }, s.threat_types.join(", ")) : null,
      s.heuristics && s.heuristics.length ? h("p", { class: "small muted" }, s.heuristics.join(" · ")) : null);
  }));
}

/* Fresh credentials + explicit confirmation for irreversible deletion actions. */
function accountDeletionDialog({ title, description, endpoint, moderator = false, onSuccess }) {
  const modal = h("dialog", { class: "delete-dialog" });
  const pw = h("input", { type: "password", required: true, autocomplete: "current-password" });
  const totp = h("input", { type: "text", inputMode: "numeric", placeholder: "Only if MFA is enabled" });
  const confirmation = h("input", { type: "text", required: true, placeholder: "DELETE" });
  const modkey = h("input", { type: "password", placeholder: "Owner-provided moderation key" });
  const error = h("div");
  const form = h("form", { onsubmit: async e => {
    e.preventDefault();
    const payload = { password: pw.value, totp: totp.value || null, confirm: confirmation.value };
    if (moderator) payload.moderator_delete_key = modkey.value;
    try {
      await api(endpoint, { method: "DELETE", json: payload, noRedirect: true });
      modal.close(); modal.remove(); toast("Account permanently removed");
      if (onSuccess) onSuccess();
    } catch (ex) { clear(error).append(notice("err", ex.message)); }
  } }, h("h2", {}, title), h("p", { class: "muted small" }, description),
    h("p", { class: "msg err" }, "Permanent deletion: all chat history shared with the deleted child and associated images and alerts will be removed for both children."),
    h("label", {}, "Your account password"), pw,
    h("label", {}, "Authenticator code (if MFA is on)"), totp,
    ...(moderator ? [h("label", {}, "Moderator deletion key"), modkey] : []),
    h("label", {}, "Type DELETE to confirm"), confirmation, error,
    h("div", { class: "row" },
      h("button", { class: "btn danger", type: "submit" }, "Permanently delete"),
      h("button", { class: "btn ghost", type: "button", onclick: () => modal.close() }, "Cancel")));
  modal.addEventListener("close", () => modal.remove());
  modal.append(form);
  document.body.append(modal);
  modal.showModal();
}
