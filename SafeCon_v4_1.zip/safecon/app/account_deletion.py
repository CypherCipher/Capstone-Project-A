"""Destructive account removal. No child records are silently orphaned.

Prototype semantics: permanently delete child conversations (including other
participants' copies), associated alerts/messages/warnings/images, and account
records. Ask for fresh password/MFA and a confirmation phrase before deletion.
"""
from pathlib import Path

import pyotp
from fastapi import HTTPException
from sqlalchemy.orm import Session

from . import config
from .db import (Alert, AuditLog, Conversation, InterestCount, Message,
                 Notification, StarEvent, User, Violation)
from .security import verify_password, sec_log


def verify_deletion(actor: User, password: str, totp: str | None, confirm: str) -> None:
    if confirm != "DELETE":
        raise HTTPException(400, 'Type DELETE to confirm this irreversible action.')
    if not verify_password(actor.password_hash, password):
        raise HTTPException(403, "Incorrect password.")
    if actor.mfa_enabled and (not totp or not pyotp.TOTP(actor.mfa_secret).verify(totp, valid_window=1)):
        raise HTTPException(403, "A valid MFA code is required.")


def remove_account(db: Session, target: User) -> None:
    """Hard-delete user data; reject parents with child accounts to prevent orphaning.

    WARNING: shared conversations are deleted for BOTH participants. This is
    stated in the UI and README. File deletion occurs after the DB commits.
    """
    if target.role == "parent" and db.query(User.id).filter(User.parent_id == target.id).first():
        raise HTTPException(409, "Delete or transfer linked child accounts before deleting this parent account.")
    uploads: list[str] = []
    if target.role == "child":
        conv_ids = [c.id for c in db.query(Conversation).filter(
            (Conversation.user_a == target.id) | (Conversation.user_b == target.id)).all()]
        if conv_ids:
            messages = db.query(Message).filter(Message.conversation_id.in_(conv_ids)).all()
            ids = [m.id for m in messages]
            uploads = [m.image_path for m in messages if m.image_path]
            if ids:
                db.query(Violation).filter(Violation.message_id.in_(ids)).delete(synchronize_session=False)
                db.query(StarEvent).filter(StarEvent.message_id.in_(ids)).delete(synchronize_session=False)
            db.query(Alert).filter(Alert.conversation_id.in_(conv_ids)).delete(synchronize_session=False)
            db.query(Message).filter(Message.conversation_id.in_(conv_ids)).delete(synchronize_session=False)
            db.query(Conversation).filter(Conversation.id.in_(conv_ids)).delete(synchronize_session=False)
        db.query(Violation).filter(Violation.child_id == target.id).delete(synchronize_session=False)
        db.query(StarEvent).filter(StarEvent.child_id == target.id).delete(synchronize_session=False)
        db.query(InterestCount).filter(InterestCount.child_id == target.id).delete(synchronize_session=False)
        if target.parent_id:
            # Do not retain child names in parent-facing notification strings.
            for n in db.query(Notification).filter(Notification.user_id == target.parent_id).all():
                if target.full_name.lower() in (n.text or "").lower():
                    db.delete(n)
    # Keep moderator decisions, but remove reviewer linkage if their account is removed.
    db.query(Alert).filter(Alert.reviewer_id == target.id).update({"reviewer_id": None}, synchronize_session=False)
    db.query(Violation).filter(Violation.reviewer_id == target.id).update({"reviewer_id": None}, synchronize_session=False)
    db.query(Notification).filter(Notification.user_id == target.id).delete(synchronize_session=False)
    db.query(AuditLog).filter(AuditLog.user_id == target.id).delete(synchronize_session=False)
    target_id, role = target.id, target.role
    db.delete(target)
    db.commit()
    root = config.UPLOAD_DIR.resolve()
    for fname in uploads:
        try:
            file_path = (root / fname).resolve()
            if file_path.parent == root:
                file_path.unlink(missing_ok=True)
        except OSError:
            sec_log("account_deletion_upload_cleanup_failed", role=role)
    # No child's name, username, or conversation text in this event.
    sec_log("account_deleted", role=role)
