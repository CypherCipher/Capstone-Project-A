"""Safe URL reputation checks. Never fetch/open user supplied hosts or page content.

Metadata is derived locally from the URL syntax (not downloaded HTML). An optional
Google Safe Browsing v5 lookup checks known malware/social-engineering threats.
Only scheme, host, port, and path are transmitted: query/fragment/userinfo are removed
before third-party lookup to reduce the chance of leaking tokens or personal data.
"""
from __future__ import annotations

import ipaddress
import re
import threading
import time
from urllib.parse import urlsplit, urlunsplit

import httpx

from . import config
from .nlp.sensitive import URL

LOOKUP_ENDPOINT = "https://safebrowsing.googleapis.com/v5/urls:search"
MAX_URLS_PER_MESSAGE = 3
_CACHE: dict[str, tuple[float, list[str], bool]] = {}
_LOCK = threading.Lock()
_SUSPICIOUS = re.compile(r"\b(?:verify[-_]?account|reset[-_]?password|free[-_]?gift|claim[-_]?prize|crypto[-_]?wallet|" 
                         r"wallet[-_]?connect|urgent[-_]?login|bank[-_]?security)\b", re.I)
_SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy"}


def extract(text: str) -> list[str]:
    result = []
    for m in URL.finditer(text or ""):
        raw = m.group(0).rstrip(".,;:!?)]}>'\"")
        if raw and raw not in result:
            result.append(raw)
    return result[:MAX_URLS_PER_MESSAGE]


def _parse(raw: str) -> tuple[str | None, dict]:
    # urlsplit does not open a network connection.
    value = raw if raw.lower().startswith(("https://", "http://")) else "https://" + raw
    try:
        parsed = urlsplit(value)
        host = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port
        if parsed.scheme not in {"http", "https"} or not host or len(value) > 2048:
            raise ValueError("invalid URL")
        ascii_host = host.encode("idna").decode("ascii")
        if any(c.isspace() for c in ascii_host) or len(ascii_host) > 253 or not re.fullmatch(r"[a-z0-9.\-:]+", ascii_host):
            raise ValueError("invalid host")
        address = None
        try: address = ipaddress.ip_address(ascii_host.strip("[]"))
        except ValueError: pass
        reasons = []
        if parsed.username or parsed.password or "@" in parsed.netloc:
            reasons.append("URL contains an embedded username or misleading @ sign")
        if address:
            reasons.append("URL uses a direct IP address")
            if not address.is_global:
                reasons.append("URL targets a non-public network address")
        elif "." not in ascii_host or ascii_host.endswith((".local", ".internal", ".test")):
            reasons.append("URL uses a private or non-public hostname")
        if ascii_host.startswith("xn--") or ".xn--" in ascii_host:
            reasons.append("Internationalized/punycode hostname")
        if ascii_host in _SHORTENERS:
            reasons.append("Shortened link hides its destination")
        if parsed.scheme == "http":
            reasons.append("URL does not use HTTPS")
        if _SUSPICIOUS.search((parsed.path or "") + " " + ascii_host):
            reasons.append("URL contains common phishing-like wording")
        if ascii_host.count(".") >= 4:
            reasons.append("Unusually many hostname subdomains")
        if port and port not in (80, 443):
            reasons.append("Unusual port number")
        # Never send query strings, fragments, or credentials to the lookup service.
        netloc = ascii_host if ":" not in ascii_host else f"[{ascii_host}]"
        if port:
            netloc += f":{port}"
        lookup_url = urlunsplit((parsed.scheme, netloc, parsed.path or "/", "", ""))
        private = bool(address and not address.is_global) or bool(
            not address and ("." not in ascii_host or ascii_host.endswith((".local", ".internal", ".test"))))
        metadata = {"host": ascii_host[:253], "scheme": parsed.scheme, "path_length": len(parsed.path or ""),
                    "query_present": bool(parsed.query), "heuristics": reasons[:8],
                    "private_target": private}
        return lookup_url, metadata
    except (ValueError, UnicodeError):
        return None, {"host": "invalid URL", "scheme": "unknown", "path_length": 0,
                      "query_present": False, "heuristics": ["URL could not be parsed"], "private_target": True}


def _known_threats(lookup_url: str) -> tuple[list[str], bool]:
    if not config.SAFE_BROWSING_KEY:
        return [], False
    with _LOCK:
        c = _CACHE.get(lookup_url)
        if c and c[0] > time.monotonic():
            return c[1], c[2]
    try:
        # Request goes ONLY to the fixed Google endpoint. We never browse the submitted URL.
        response = httpx.get(LOOKUP_ENDPOINT, params={"key": config.SAFE_BROWSING_KEY, "urls": lookup_url},
                             timeout=4.0, follow_redirects=False)
        response.raise_for_status()
        data = response.json()
        threats = sorted({t for hit in data.get("threats", []) for t in hit.get("threatTypes", [])})
        duration = data.get("cacheDuration", "300s")
        try:
            ttl = max(1, min(86400, int(float(str(duration).rstrip("s")))))
        except (TypeError, ValueError):
            ttl = 300
        with _LOCK:
            _CACHE[lookup_url] = (time.monotonic() + ttl, threats, True)
        return threats, True
    except (httpx.HTTPError, ValueError, TypeError, KeyError):
        return [], False  # API outage must never produce a 'safe' verdict


def scan(text: str) -> list[dict]:
    """Return safe-to-display metadata. No raw URL is stored or returned."""
    out = []
    for raw in extract(text):
        lookup_url, meta = _parse(raw)
        threats, checked = _known_threats(lookup_url) if lookup_url and not meta["private_target"] else ([], False)
        # Known threat beats heuristics. No hit is NOT a guarantee of safety.
        state = "malicious" if threats else "suspicious" if meta["heuristics"] else "no_known_threats" if checked else "unverified"
        out.append({**meta, "verdict": state, "provider": "Google Safe Browsing v5" if checked else "not checked",
                    "threat_types": threats})
    return out
