from datetime import datetime, timedelta, timezone
import re
import secrets

from sqlalchemy import (JSON, Boolean, Column, DateTime, Float, Integer, LargeBinary,
                        String, create_engine, inspect, text)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import declarative_base, sessionmaker

from .config import DB_URL


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
Base = declarative_base()


class Institution(Base):
    __tablename__ = "institutions"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), unique=True, nullable=False)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(32), unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String(12), nullable=False)            # child | parent | moderator
    full_name = Column(String(60), nullable=False)
    institution_id = Column(Integer, index=True)
    parent_id = Column(Integer, index=True)              # for child accounts
    child_code = Column(String(16), unique=True, index=True, nullable=True)  # persistent public identifier
    active = Column(Boolean, default=True)
    failed_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)
    mfa_secret = Column(String)
    mfa_enabled = Column(Boolean, default=False)
    warning_count = Column(Integer, default=0)           # confirmed warnings since last restriction
    restricted_until = Column(DateTime)
    stars = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)


class ChildIDReservation(Base):
    """Permanent ledger of issued public child IDs, including deleted accounts.

    Never remove a reservation during account deletion. Public IDs are for display
    and search only; they must never be treated as credentials or authorizations.
    """
    __tablename__ = "child_id_reservations"
    code = Column(String(5), primary_key=True)


class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True)
    user_a = Column(Integer, index=True, nullable=False)
    user_b = Column(Integer, index=True, nullable=False)
    created_at = Column(DateTime, default=utcnow)


class Message(Base):
    """Chat storage. Text and images are encrypted (AES-256-GCM) and deleted after 30 days."""
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, index=True, nullable=False)
    sender_id = Column(Integer, index=True, nullable=False)
    ciphertext = Column(LargeBinary, nullable=False)
    image_path = Column(String)
    image_flagged = Column(Boolean, default=False)
    url_scans = Column(JSON, default=list)  # sanitized URL safety metadata; NO full URL
    created_at = Column(DateTime, default=utcnow, index=True)
    expires_at = Column(DateTime, index=True)


class Alert(Base):
    """Holds NO message text or images - only risk metadata (deleted after 90 days)."""
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, index=True, nullable=False)
    message_id = Column(Integer)            # last flagged message (looked up in encrypted chat storage)
    trigger_user_id = Column(Integer)       # sender of the latest flagged message
    risk_level = Column(String(8), nullable=False)
    text_conf = Column(Float, default=0.0)
    image_conf = Column(Float)
    confidence = Column(Float, default=0.0)
    indicators = Column(JSON, default=list)
    explanation = Column(JSON, default=list)   # SHAP token weights
    model_source = Column(String(40))
    status = Column(String(12), default="new", index=True)   # new|reviewing|confirmed|dismissed|escalated
    reviewer_id = Column(Integer)
    note = Column(String(200))
    created_at = Column(DateTime, default=utcnow, index=True)
    updated_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, index=True)


class Violation(Base):
    """A *possible* violation by a child (shared personal info / explicit image). Moderator must confirm."""
    __tablename__ = "violations"
    id = Column(Integer, primary_key=True)
    child_id = Column(Integer, index=True, nullable=False)
    message_id = Column(Integer)
    kind = Column(String(20), nullable=False)    # personal_info | explicit_image
    reason = Column(String(120), nullable=False)
    status = Column(String(10), default="pending", index=True)  # pending|confirmed|dismissed
    reviewer_id = Column(Integer)
    created_at = Column(DateTime, default=utcnow)
    reviewed_at = Column(DateTime)


class InterestCount(Base):
    """Only broad interest categories are kept - never conversation details."""
    __tablename__ = "interests"
    child_id = Column(Integer, primary_key=True)
    category = Column(String(20), primary_key=True)
    count = Column(Integer, default=0)


class StarEvent(Base):
    __tablename__ = "star_events"
    id = Column(Integer, primary_key=True)
    child_id = Column(Integer, index=True)
    message_id = Column(Integer)
    created_at = Column(DateTime, default=utcnow)


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    text = Column(String(200))
    read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    action = Column(String(40))
    target = Column(String(80))
    ip = Column(String(45))
    created_at = Column(DateTime, default=utcnow, index=True)


_FIVE_DIGIT_ID = re.compile(r"[1-9][0-9]{4}\Z")


def new_child_code(db) -> str:
    """Generate and reserve a random, unique 5-digit child ID (10000–99999).

    secrets is a cryptographically secure RNG. Both the users table unique index
    and the permanent reservation table protect against duplicate issuance. The
    reservation is committed with the new user, so a failed user creation does
    not consume the number.
    """
    for _ in range(1000):
        code = str(10000 + secrets.randbelow(90000))
        if db.get(ChildIDReservation, code) is not None:
            continue
        # Protect against databases partially migrated by an older version.
        if db.query(User.id).filter(User.child_code == code).first():
            continue
        try:
            with db.begin_nested():
                db.add(ChildIDReservation(code=code))
                db.flush()
            return code
        except IntegrityError:
            # Another writer may have reserved the candidate concurrently.
            continue
    raise RuntimeError("Could not allocate an unused child ID; please try again.")


def _reserve_existing_five_digit_ids(db):
    """Retain valid 5-digit IDs and permanently record their issuance."""
    existing = db.query(User.child_code).filter(User.child_code.is_not(None)).all()
    for (code,) in existing:
        if code and _FIVE_DIGIT_ID.fullmatch(code) and db.get(ChildIDReservation, code) is None:
            db.add(ChildIDReservation(code=code))
            db.flush()


def init_db():
    Base.metadata.create_all(engine)
    # Additive SQLite upgrade. Keep accounts, messages, encryption keys, and any
    # old child_code_sequence table. Do NOT remove or reseed any data.
    if DB_URL.startswith("sqlite"):
        with engine.begin() as con:
            tables = inspect(con)
            if "users" in tables.get_table_names() and "child_code" not in {c["name"] for c in tables.get_columns("users")}:
                con.execute(text("ALTER TABLE users ADD COLUMN child_code VARCHAR(16)"))
            if "messages" in tables.get_table_names() and "url_scans" not in {c["name"] for c in tables.get_columns("messages")}:
                con.execute(text("ALTER TABLE messages ADD COLUMN url_scans JSON"))
            con.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_users_child_code ON users (child_code)"))
    with SessionLocal() as db:
        # Preserve already-issued random codes across restarts and upgrades.
        _reserve_existing_five_digit_ids(db)
        # Upgrade legacy S1 / SC-XXXX-XXXX / missing IDs to the random 5-digit
        # format once. Existing valid 5-digit IDs remain unchanged thereafter.
        for child in db.query(User).filter(User.role == "child").order_by(User.id).all():
            if not child.child_code or not _FIVE_DIGIT_ID.fullmatch(child.child_code):
                child.child_code = new_child_code(db)
                db.flush()
        db.commit()
