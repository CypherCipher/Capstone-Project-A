from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .. import services
from ..db import Alert, Conversation, Notification, User, utcnow
from ..deps import audit, current_user, get_db, require
from ..nlp.risk import RANK

router = APIRouter(prefix="/api/alerts", tags=["alerts"])
STATUSES = ("new", "reviewing", "confirmed", "dismissed", "escalated")


class StatusIn(BaseModel):
    status: str
    note: str | None = Field(default=None, max_length=200)


def _scope_conv_ids(db: Session, user: User) -> list[int]:
    """Conversation ids this user may see alerts for (parent: own children, moderator: own institution)."""
    if user.role == "parent":
        kids = [k.id for k in db.query(User).filter(User.parent_id == user.id)]
    elif user.role == "moderator":
        kids = [k.id for k in db.query(User).filter(User.role == "child", User.institution_id == user.institution_id)]
    else:
        return []
    if not kids:
        return []
    return [c.id for c in db.query(Conversation).filter(Conversation.user_a.in_(kids) | Conversation.user_b.in_(kids))]


def alert_json(db: Session, a: Alert) -> dict:
    conv = db.get(Conversation, a.conversation_id)
    names = {u.id: f"{u.full_name} ({u.child_code})" if u.child_code else u.full_name
             for u in db.query(User).filter(User.id.in_([conv.user_a, conv.user_b]))} if conv else {}
    return {"id": a.id, "risk_level": a.risk_level, "confidence": round(a.confidence or 0, 3),
            "text_conf": round(a.text_conf or 0, 3), "image_conf": None if a.image_conf is None else round(a.image_conf, 3),
            "indicators": a.indicators or [], "explanation": a.explanation or [], "status": a.status,
            "note": a.note, "model_source": a.model_source, "conversation_id": a.conversation_id,
            "participants": list(names.values()), "trigger": names.get(a.trigger_user_id, "?"),
            "created_at": a.created_at.isoformat(), "updated_at": a.updated_at.isoformat()}


def _get_visible(db: Session, user: User, alert_id: int) -> Alert:
    a = db.get(Alert, alert_id)
    if not a or a.conversation_id not in _scope_conv_ids(db, user):
        raise HTTPException(404, "Alert not found.")
    return a


@router.get("")
def list_alerts(status: str | None = None, user: User = Depends(require("parent", "moderator")),
                db: Session = Depends(get_db)):
    ids = _scope_conv_ids(db, user)
    q = db.query(Alert).filter(Alert.conversation_id.in_(ids)) if ids else None
    if q is None:
        return []
    if status:
        q = q.filter(Alert.status == status)
    rows = q.order_by(Alert.id.desc()).limit(200).all()
    rows.sort(key=lambda a: (a.status not in ("new", "reviewing"), -RANK[a.risk_level], -a.id))
    return [alert_json(db, a) for a in rows]


@router.get("/{alert_id}")
def get_alert(alert_id: int, user: User = Depends(require("parent", "moderator")), db: Session = Depends(get_db)):
    return alert_json(db, _get_visible(db, user, alert_id))


@router.get("/{alert_id}/messages")
def alert_messages(alert_id: int, request: Request, user: User = Depends(require("parent", "moderator")),
                   db: Session = Depends(get_db)):
    """Flagged messages are read straight from the encrypted chat store (never copied into the alert)."""
    a = _get_visible(db, user, alert_id)
    audit(db, user, "view_flagged_messages", f"alert {a.id}", request)
    msgs = services.window(db, a.conversation_id, a.message_id)
    names = {u.id: f"{u.full_name} ({u.child_code})" if u.child_code else u.full_name
             for u in db.query(User).filter(User.id.in_([m.sender_id for m in msgs]))}
    if not msgs:
        return {"expired": True, "messages": []}
    return {"expired": False, "messages": [
        {"id": m.id, "sender": names.get(m.sender_id, "?"), "text": services.message_text(m),
         "image_url": f"/api/media/{m.id}" if m.image_path else None, "image_flagged": m.image_flagged, "url_scans": m.url_scans or [],
         "is_trigger": m.id == a.message_id, "created_at": m.created_at.isoformat()} for m in msgs]}


@router.patch("/{alert_id}")
def update_alert(alert_id: int, body: StatusIn, request: Request, user: User = Depends(require("moderator")),
                 db: Session = Depends(get_db)):
    if body.status not in STATUSES:
        raise HTTPException(400, "Unknown status.")
    a = _get_visible(db, user, alert_id)
    a.status, a.reviewer_id, a.updated_at = body.status, user.id, utcnow()
    if body.note is not None:
        a.note = body.note.strip() or None
    conv = db.get(Conversation, a.conversation_id)
    if body.status in ("confirmed", "escalated"):
        for k in db.query(User).filter(User.id.in_([conv.user_a, conv.user_b])):
            if k.parent_id:
                db.add(Notification(user_id=k.parent_id, created_at=utcnow(),
                                    text=f"A moderator reviewed an alert about {k.full_name}'s chat and marked it "
                                         f"'{body.status}'. Please open Alerts for details."))
    db.commit()
    audit(db, user, f"alert_{body.status}", f"alert {a.id}", request)
    return alert_json(db, a)
