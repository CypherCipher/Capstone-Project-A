"""Central settings. Everything can be overridden with environment variables."""
import base64
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("SAFECON_DATA_DIR", BASE_DIR / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
SECRET_DIR = DATA_DIR / ".secrets"
STATIC_DIR = BASE_DIR / "static"
for _d in (DATA_DIR, UPLOAD_DIR, SECRET_DIR):
    _d.mkdir(parents=True, exist_ok=True)


def _secret(env: str, fname: str, make) -> str:
    """Read a secret from the environment, else from data/.secrets (created on first run)."""
    value = os.getenv(env)
    if value:
        return value
    path = SECRET_DIR / fname
    if path.exists():
        return path.read_text().strip()
    value = make()
    path.write_text(value)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return value


JWT_SECRET = _secret("SAFECON_JWT_SECRET", "jwt_secret", lambda: secrets.token_urlsafe(48))
# AES-256 key (32 random bytes, urlsafe-base64) used to encrypt chat messages and images
DATA_KEY = base64.urlsafe_b64decode(
    _secret("SAFECON_DATA_KEY", "data_key", lambda: base64.urlsafe_b64encode(os.urandom(32)).decode())
)
# Key for the service-to-service /api/analyze endpoint
API_KEY = _secret("SAFECON_API_KEY", "api_key", lambda: secrets.token_urlsafe(32))

DB_URL = os.getenv("SAFECON_DB_URL", f"sqlite:///{DATA_DIR / 'safecon.db'}")

# --- Sessions / auth ---
COOKIE_NAME = "sc_token"
COOKIE_SECURE = os.getenv("SAFECON_COOKIE_SECURE", "0") == "1"  # set to 1 behind HTTPS
JWT_MINUTES = int(os.getenv("SAFECON_JWT_MINUTES", "60"))
MAX_FAILED_LOGINS = 5
LOCKOUT_MINUTES = 15

# --- Retention (from the proposal) ---
MESSAGE_RETENTION_DAYS = int(os.getenv("SAFECON_MESSAGE_DAYS", "30"))
ALERT_RETENTION_DAYS = int(os.getenv("SAFECON_ALERT_DAYS", "90"))

# --- Warning / restriction system ---
WARNING_LIMIT = 3
RESTRICTION_HOURS = 24

# --- Risk thresholds (proposal section 4.3; starting values) ---
HIGH_CONF = 0.8
MED_CONF = 0.5
IMAGE_NSFW_THRESHOLD = 0.7
WINDOW_MESSAGES = 12          # messages per conversation window
ALERT_MERGE_MINUTES = 15

# --- Models (all run locally) ---
TEXT_MODEL_ID = os.getenv("SAFECON_TEXT_MODEL", "erikaecl/hansen-grooming-distilbert")
# If the label names of the model are unclear, set this to the label that means "grooming" (e.g. LABEL_1)
TEXT_GROOMING_LABEL = os.getenv("SAFECON_TEXT_GROOMING_LABEL", "")
IMAGE_MODEL_ID = os.getenv("SAFECON_IMAGE_MODEL", "Falconsai/nsfw_image_detection")
EMBED_MODEL_ID = os.getenv("SAFECON_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
# "auto" = try to load real models, fall back if that fails. "off" = never load them (tests / fast start).
MODELS_MODE = os.getenv("SAFECON_MODELS", "auto")
SHAP_ENABLED = os.getenv("SAFECON_SHAP", "1") == "1"

MAX_TEXT_LEN = 1000
MAX_IMAGE_BYTES = 5 * 1024 * 1024

# URL checks: Google Safe Browsing v5 (non-commercial academic use only).
# Without a key, scans return 'unverified'; never treat this as clean.
SAFE_BROWSING_KEY = os.getenv("SAFECON_SAFE_BROWSING_KEY", "")
# Moderator deletion is disabled until the project owner enables this separate guard.
MOD_DELETE_KEY = os.getenv("SAFECON_MOD_DELETE_KEY", "")
