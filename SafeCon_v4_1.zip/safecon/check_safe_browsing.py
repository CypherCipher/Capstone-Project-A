"""Check the Google Safe Browsing API setup without printing your API key.

Run from the SafeCon project folder AFTER setting SAFECON_SAFE_BROWSING_KEY
in the current PowerShell session. Contacts Google's fixed API endpoint only,
never opens the test URL itself.
"""
import sys

import httpx

from app import config
from app.url_safety import LOOKUP_ENDPOINT


def main() -> int:
    if not config.SAFE_BROWSING_KEY:
        print("NOT CONFIGURED: SAFECON_SAFE_BROWSING_KEY is missing in this terminal.")
        return 1
    print("API key detected (value hidden). Testing Google's lookup service...")
    # This is an established Google Safe Browsing *test* URL; do not browse it.
    test_url = "https://testsafebrowsing.appspot.com/s/malware.html"
    try:
        response = httpx.get(LOOKUP_ENDPOINT, params={"key": config.SAFE_BROWSING_KEY, "urls": test_url},
                             timeout=10.0, follow_redirects=False)
    except httpx.HTTPError as ex:
        print(f"Network error: {type(ex).__name__}. Check your connection.")
        return 2
    if response.status_code != 200:
        print(f"Google returned HTTP {response.status_code}. Check that Safe Browsing APIs are enabled and the key is allowed to call them.")
        return 3
    try:
        matches = response.json().get("threats", [])
    except (ValueError, AttributeError):
        print("Google responded, but the response was not the expected JSON.")
        return 4
    types = sorted({t for match in matches for t in match.get("threatTypes", [])})
    print("SUCCESS: Live Google Safe Browsing API call returned HTTP 200.")
    print("Test URL verdict:", ", ".join(types) if types else "no known threat matched this test request")
    print("Note: A successful check does not guarantee other links are safe.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
